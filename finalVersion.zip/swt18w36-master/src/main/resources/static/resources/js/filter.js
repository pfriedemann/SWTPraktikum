function filterUser(event) {
  const input = document.getElementById("filter").value;
  const table = document.getElementById("userTable");
  const tableBody = table.querySelector("#tableBody");
  const rowArray = [...tableBody.children];
  rowArray.forEach(row => {
    const cols = [...row.children];
    let includesInput = false;
    cols.forEach(col => {
      console.log(col.innerHTML);
      console.log(input);
      console.log(col.innerHTML.toLowerCase().includes(input.toLowerCase()));
      if (!col.innerHTML) return;
      if (col.innerHTML.includes("</form>")) return;
      if (col.innerHTML.toLowerCase().includes(input.toLowerCase()))
        includesInput = true;
    });
    if (!includesInput) row.classList.add("hideRow");
    if (includesInput) row.classList.remove("hideRow");
  });
}
