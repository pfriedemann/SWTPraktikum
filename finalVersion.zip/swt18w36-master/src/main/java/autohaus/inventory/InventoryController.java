
package autohaus.inventory;

import org.salespointframework.quantity.Quantity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Controller for Inventory related things
 * @author Nico
 *
 */
@Controller
class InventoryController {

    private final MultiLocationInventory inventory;
    private final LocationRepository locations;

    InventoryController(MultiLocationInventory inventory, LocationRepository locations) {
        this.inventory = inventory;
        this.locations = locations;
    }

    /**
     * gives a list of Locations with an inventory
     * @param model
     * @return
     */
    @GetMapping("/inventory")
    @PreAuthorize("hasAnyRole('ROLE_BOSS','ROLE_EMPLOYEE')")
    String showLocations(Model model) {
        model.addAttribute("locations", locations.findAll());
        return "locations";
    }

    /**
     * shows the stock of the given @class Location
     * @param model
     * @param location requested location
     * @return
     */
    @GetMapping("/inventory/{location}")
    @PreAuthorize("hasAnyRole('ROLE_BOSS','ROLE_EMPLOYEE')")
    String showLocalInventory(Model model, @PathVariable Location location) {
        model.addAttribute("location", location);
        model.addAttribute("stock", inventory.findByLocation(location));
        return "stock";
    }

    /**
     * Post Mapping for changing the quantity of an @class ResidentInventoryItem
     * @param item
     * @param quantity
     * @param location
     * @param action
     * @return
     */
    @PostMapping("/inventory/{location}")
    @PreAuthorize("hasAnyRole('ROLE_BOSS','ROLE_EMPLOYEE')")
    String changeQuantity(@RequestParam("item") ResidentInventoryItem item, @RequestParam("amount") Quantity quantity,
            @PathVariable Location location, @RequestParam("action") String action,RedirectAttributes ra) {
        //Available actions
        final String actionDecrease = new String("decrease");
        final String actionIncrease = new String("increase");
        //add information
        ra.addFlashAttribute("message_product",item.getProduct());
        ra.addFlashAttribute("message_quantity",quantity);
        
        if (action.equals(actionIncrease)) {
            item.increaseQuantity(quantity);
            inventory.save(item);
            ra.addFlashAttribute("message_success", "inventory.added_items.success");
        } else if (action.equals(actionDecrease)) {
            if (item.hasSufficientQuantity(quantity)) {
                item.decreaseQuantity(quantity);
                inventory.save(item);
                ra.addFlashAttribute("message_success", "inventory.removed_items.success");
            } else {
                ra.addFlashAttribute("error_cant_satisfy", "inventory.removed_items.failed");
            }
        } else {
            ra.addFlashAttribute("error_unknown_action", "inventory.invalid_action");
        }
        return "redirect:/inventory/" + location.getId().toString();
    }
}