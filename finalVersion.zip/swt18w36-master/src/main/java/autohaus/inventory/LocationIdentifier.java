package autohaus.inventory;

import javax.persistence.Embeddable;

import org.salespointframework.core.SalespointIdentifier;

/**
 * Class for Type safety
 * 
 * @author Nico
 *
 */
@Embeddable
public final class LocationIdentifier extends SalespointIdentifier {
    private static final long serialVersionUID = 7996773055392840113L;

    public LocationIdentifier() {
        super();
    }

    public LocationIdentifier(String id) {
        super(id);
    }
}
