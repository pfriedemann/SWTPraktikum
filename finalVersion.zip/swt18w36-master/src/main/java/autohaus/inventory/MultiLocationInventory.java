package autohaus.inventory;

import java.util.Optional;

import org.salespointframework.catalog.Product;
import org.salespointframework.catalog.ProductIdentifier;
import org.salespointframework.quantity.Quantity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.util.Streamable;

/**
 * Inventory Interface that supports Multiple Locations similar to Salespoint's
 * Inventory but methods mostly return multiple values and require an additional
 * Location parameter
 * 
 * @author Nico
 *
 */
public interface MultiLocationInventory extends CrudRepository<ResidentInventoryItem, Long> {
    /**
     * returns the items from the specified location sorted by id
     * 
     * @param location
     * @return
     */
    public @Query("select i from ResidentInventoryItem i where i.location = ?1 order by i.id")
    Streamable<ResidentInventoryItem> findByLocation(Location location);

    /**
     * finds items from all location having the product Identifier
     * 
     * @param productIdentifier
     * @return
     */
    @Query("select i from ResidentInventoryItem i where i.product.id = ?1")
    public Streamable<ResidentInventoryItem> findByProductIdentifier(ProductIdentifier productIdentifier);

    public default Streamable<ResidentInventoryItem> findByProduct(Product product) {
        return findByProductIdentifier(product.getId());
    }

    /**
     * 
     * @param product
     * @param location
     * @return one item
     */
    @Query("select i from ResidentInventoryItem i where i.product = ?1 and i.location = ?2")
    public Optional<ResidentInventoryItem> findByProductAndLocation(Product product, Location location);

    /**
     * finds everything with quantity <= 0
     * @param location to search
     * @return
     */
    public @Query("select i from ResidentInventoryItem i where i.location = ?1 and i.quantity.amount <= 0")
    Streamable<ResidentInventoryItem> findItemsOutOfStock(Location location);
    
    /**
     * @param product
     * @return total stock of an product across all locations
     */
    public default Quantity totalStockOf(Product product) {
        Quantity stock = Quantity.of(0);
        for (ResidentInventoryItem item : findByProduct(product)) {
            stock = stock.add(item.getQuantity());
        }
        return stock;
    }
}
