package autohaus.inventory;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface LocationRepository extends CrudRepository<Location, LocationIdentifier> {
    /**
     * @param name
     * @return Location with the specified name
     */
    @Query("select i from Location i where i.name = ?1")
    Optional<Location> findByName(String name);
}
