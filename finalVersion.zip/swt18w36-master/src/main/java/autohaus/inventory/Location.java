package autohaus.inventory;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

import org.salespointframework.core.AbstractEntity;

/**
 * Object representing a location
 * @author Nico
 *
 */
@Entity
public class Location extends AbstractEntity<LocationIdentifier>{
    /*@Id
    @GeneratedValue
    private long id;*/
    
    @EmbeddedId
    @AttributeOverride(name = "id", column = @Column(name = "LOCATION_ID"))
    private LocationIdentifier id = new LocationIdentifier();

    @Column(unique = true)
    private String name;
    private String address;

    /**
     * only JPA needs this
     */
    protected Location() {
    }

    /**
     * 
     * @param name    unique name of the location
     * @param address
     */
    public Location(String name, String address) {
        this.name = name;
        this.address = address;
    }
    /**
     * creates a Location with name = name
     * address is an empty string
     * @param name
     */
    public Location(String name) {
        this.name = name;
        this.address = "";
    }

    public String getAddress() {
        return this.address;
    }

    public String getName() {
        return this.name;
    }

    public LocationIdentifier getId() {
        return this.id;
    }
}
