package autohaus.inventory;

public class OutOfStockException extends RuntimeException {
    private static final long serialVersionUID = 6338769617966862520L;

    public OutOfStockException() {
        super();
    }

    public OutOfStockException(String message) {
        super(message);
    }
}