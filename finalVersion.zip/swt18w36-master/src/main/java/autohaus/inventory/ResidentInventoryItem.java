package autohaus.inventory;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.salespointframework.catalog.Product;
import org.salespointframework.core.AbstractEntity;
import org.salespointframework.quantity.Quantity;
import org.springframework.util.Assert;

/**
 * like Salespoint's InventoryItem class
 * needed for use with the MultiLocationInventory interface
 * 
 * @author Nico
 *
 */
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "product_id", "location_id" }) })
@Entity
public class ResidentInventoryItem extends AbstractEntity<ResidentInventoryItemIdentifier> {

    @EmbeddedId
    private ResidentInventoryItemIdentifier id = new ResidentInventoryItemIdentifier();

    //unlike InventoryItem product doesn't have an unique constraint only on product
    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;

    @ManyToOne
    @JoinColumn(name = "location_id")
    private Location location;

    private Quantity quantity;

    protected ResidentInventoryItem() {
    }

    public ResidentInventoryItem(Product product, Quantity quantity, Location location) {

        Assert.notNull(product, "Product must be not null!");
        Assert.notNull(quantity, "Quantity must be not null!");

        product.verify(quantity);

        this.product = product;
        this.quantity = quantity;
        this.location = location;
    }

    public Quantity getQuantity() {
        return quantity;
    }

    public Product getProduct() {
        return product;
    }

    public Location getLocation() {
        return location;
    }

    /**
     * 
     * @return will never be {@literal null}.
     */
    public ResidentInventoryItemIdentifier getId() {
        return id;
    }

    public boolean hasSufficientQuantity(Quantity quantity) {
        return this.quantity.isGreaterThanOrEqualTo(quantity);
    }

    public void decreaseQuantity(Quantity quantity) {

        Assert.notNull(quantity, "Quantity must not be null!");
        Assert.isTrue(this.quantity.isGreaterThanOrEqualTo(quantity), String
                .format("Insufficient quantity! Have %s but was requested to reduce by %s.", this.quantity, quantity));

        product.verify(quantity);

        this.quantity = this.quantity.subtract(quantity);
    }

    public void increaseQuantity(Quantity quantity) {

        Assert.notNull(quantity, "Quantity must not be null!");
        product.verify(quantity);

        this.quantity = this.quantity.add(quantity);
    }
}
