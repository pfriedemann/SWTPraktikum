package autohaus.inventory;

import javax.persistence.Embeddable;

import org.salespointframework.core.SalespointIdentifier;

/**
 * Class for type safety
 * @author Nico
 *
 */
@Embeddable
public final class ResidentInventoryItemIdentifier extends SalespointIdentifier {
    private static final long serialVersionUID = -4820238296805573589L;
    
    public ResidentInventoryItemIdentifier() {
        super();
    }

    public ResidentInventoryItemIdentifier(String id) {
        super(id);
    }
}
