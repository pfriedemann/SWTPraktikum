package autohaus.inventory;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.salespointframework.inventory.LineItemFilter;
import org.salespointframework.order.Order;
import org.salespointframework.order.Order.OrderCompleted;
import org.salespointframework.order.OrderLine;
import org.salespointframework.quantity.Quantity;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class AutohausInventoryOrderEventListener {

    private final MultiLocationInventory inventory;

    public AutohausInventoryOrderEventListener(MultiLocationInventory inventory) {
        this.inventory = inventory;
    }

    /**
     * listener for completed orders it checks the order and removes the items
     * contained in the specific order from the inventory
     * 
     * @param event
     * @throws OutOfStockException
     */
    @EventListener
    public void handleEvent(OrderCompleted event) throws OutOfStockException{
        Order order = event.getOrder();

        for (OrderLine orderLine : order.getOrderLines()) {
            Iterator<ResidentInventoryItem> items = inventory.findByProductIdentifier(orderLine.getProductIdentifier())
                    .iterator();
            Quantity remaining = orderLine.getQuantity();
            //needed for rollback orders
            Map<ResidentInventoryItem,Quantity> updatedItems = new HashMap<>();
            while (!remaining.isZeroOrNegative() && items.hasNext()) {
                ResidentInventoryItem item = items.next();
                // don't split order lines for an single Product
                // find an inventory with sufficient amount to cover the order line
                if (item.hasSufficientQuantity(remaining)) {
                    updatedItems.put(item,remaining);
                    item.decreaseQuantity(remaining);
                    inventory.save(item);
                    remaining = remaining.subtract(remaining);
                    break;
                }
            }
            if (!remaining.isZeroOrNegative()) {
                //rollback
                updatedItems.forEach( (ResidentInventoryItem item, Quantity quantity)-> {
                    item.increaseQuantity(quantity);
                    inventory.save(item);
                });
                //abort order
                throw new OutOfStockException();
            }
        }
    }

    static class Config {
        /**
         * disable automatic remove from Salespoint's inventory class
         * 
         * @return LineItemFilter.handleNone();
         */
        @Bean
        LineItemFilter filter() {
            return LineItemFilter.handleNone();
        }
    }
}