package autohaus.inventory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.salespointframework.core.DataInitializer;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Order(80)
@Component
public class LocationInitializer implements DataInitializer {

    private static Logger log = LogManager.getLogger(LocationInitializer.class);
    private final LocationRepository locations;

    public LocationInitializer(LocationRepository locations) {
        this.locations = locations;
    }

    @Override
    public void initialize() {
        if (locations.count() == 0) {
            locations.save(new Location("Dresden", "Kötzschenbroder Str. 141"));
            locations.save(new Location("Berlin", "Huttenstraße 30"));
            locations.save(new Location("Hamburg", "Geesmoor 16"));
            locations.save(new Location("Strahlsund", "Jungfernstieg 1"));
            locations.save(new Location("Wolfsburg", "Kölner Ring 15"));
            log.info("filled empty Repository with location data");
        }
    }
}
