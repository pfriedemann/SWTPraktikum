package autohaus.inventory.transport;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.salespointframework.catalog.Product;
import org.salespointframework.quantity.Quantity;
import org.salespointframework.time.BusinessTime;
import org.springframework.stereotype.Service;
import org.springframework.data.util.Streamable;
import org.springframework.scheduling.annotation.Scheduled;
import autohaus.inventory.OutOfStockException;
import autohaus.inventory.Location;
import autohaus.inventory.MultiLocationInventory;
import autohaus.inventory.ResidentInventoryItem;

/**
 * Service for Moving Stock between Locations
 * 
 * @author Nico
 *
 */
@Service
public class TransportService {
    private static final Logger log = LogManager.getLogger(TransportService.class);
    private final MultiLocationInventory inventory;
    private final TransportRepository transportRepository;
    private final BusinessTime time;

    public TransportService(MultiLocationInventory inventory, BusinessTime time,
            TransportRepository transportRepository) {
        this.inventory = inventory;
        this.time = time;
        this.transportRepository = transportRepository;
        log.info("ready");
    }

    /**
     * moves items without delay
     * 
     * @param product
     * @param quantity
     * @param from
     * @param to
     */
    public void moveItemsImmediately(Product product, Quantity quantity, Location from, Location to) {
        product.verify(quantity);
        ResidentInventoryItem source = inventory.findByProductAndLocation(product, from).orElseThrow(() -> {
            return new NoSuchElementException(
                    String.format("Location %s has no product named %s", from.getName(), product.getName()));
        });
        ResidentInventoryItem target = inventory.findByProductAndLocation(product, to).orElseGet(() -> {
            inventory.save(new ResidentInventoryItem(product, quantity, to));
            return inventory.findByProductAndLocation(product, to).orElseThrow(() -> {
                // throwing this exceptions at this point also means that the inventory query
                // method is broken
                return new NoSuchElementException(
                        String.format("Location %s has no product named %s", from.getName(), product.getName()));
            });
        });

        if (source.hasSufficientQuantity(quantity)) {
            target.increaseQuantity(quantity);
            source.decreaseQuantity(quantity);
            inventory.save(source);
            inventory.save(target);
        } else {
            throw new OutOfStockException(
                    String.format("requested %s but source only has %s", quantity, source.getQuantity()));
        }
    }

    /**
     * moves an item from A to B
     * 
     * @param from
     * @param to
     * @param product
     * @param qunatity amount to move
     * @param timeEnd  time operation finished
     */
    public void initiateTransport(Location from, Location to, Product product, Quantity quantity,
            LocalDateTime timeEnd) {
        product.verify(quantity);
        Optional<ResidentInventoryItem> optSource = inventory.findByProductAndLocation(product, from);
        Optional<ResidentInventoryItem> optTarget = inventory.findByProductAndLocation(product, to);
        if (!optSource.isPresent()) {
            throw new NoSuchElementException(String.format("cant find source item for product &s at Location %s",
                    product.getName(), from.getName()));
        }
        if (!optTarget.isPresent()) {
            throw new NoSuchElementException(String.format("cant find target item for product &s at Location %s",
                    product.getName(), to.getName()));
        }
        ResidentInventoryItem source = optSource.get();
        ResidentInventoryItem target = optTarget.get();

        // abort if there is not enough stock left to satisfy the request
        if (!source.hasSufficientQuantity(quantity)) {
            log.error(String.format("%s(%s) at %s has not enough stock left for the requested %s", source.getProduct(),
                    source.getQuantity().toString(), from.getName(), quantity.toString()));
            throw new OutOfStockException(String.format("source at %s has not enough stock left", from.getName()));
        }
        // check if time is valid
        LocalDateTime timeNow = time.getTime();
        if (timeNow.isAfter(timeEnd)) {
            throw new IllegalArgumentException(String.format("timeEnd: %s is in the past", timeEnd.toString()));
        }
        source.decreaseQuantity(quantity);
        inventory.save(source);
        Transport transport = new Transport(timeNow, timeEnd, quantity, source, target);
        transportRepository.save(transport);
        log.info(String.format("initiated Transport of %s with quantity %s from %s to %s finishing %s",
                source.getProduct().getName(), quantity.toString(), source.getLocation().getName(),
                target.getLocation().getName(), timeEnd.toString()));
    }

    Iterable<Transport> findAll() {
        Iterable<Transport> transports = transportRepository.findAll();
        LinkedList<Transport> transportList = new LinkedList<>();
        // sort by date
        for (Transport transport : transports) {
            transportList.add(transport);
        }
        Collections.sort(transportList, (Transport a, Transport b) -> {
            LocalDateTime timeA = a.getStartTime();
            LocalDateTime timeB = b.getStartTime();
            return timeA.compareTo(timeB);
        });
        return transportList;
    }

    /**
     * checks every 2s for OPEN @Class Transport instances and completes them if
     * conditions are met
     */
    @Scheduled(fixedRate = 2000)
    void taskCheckRepository() {
        Streamable<Transport> transports = transportRepository.findOpen();
        for (Transport transport : transports) {
            if (transport.getEndTime().isBefore(time.getTime())) {
                ResidentInventoryItem item = transport.getTarget();
                item.increaseQuantity(transport.getQuantity());
                transport.complete();
                transportRepository.save(transport);
                inventory.save(item);
            }
        }
    }
}
