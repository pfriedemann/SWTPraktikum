package autohaus.inventory.transport;

import java.time.LocalDateTime;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;

import org.salespointframework.catalog.Product;
import org.salespointframework.quantity.Quantity;

import autohaus.inventory.Location;
import autohaus.inventory.ResidentInventoryItem;

@Entity
class Transport {
    @EmbeddedId
    private TransportIdentifier id = new TransportIdentifier();

    private LocalDateTime startTime;
    private LocalDateTime endTime;
    @ManyToOne
    private ResidentInventoryItem source;
    @ManyToOne
    private ResidentInventoryItem target;
    private Quantity quantity;
    @Enumerated(EnumType.STRING)
    private TransportStatus status;

    public enum TransportStatus {
        UNDEFINED, OPEN, COMPLETE;
    }

    /**
     * only for JPA
     */
    protected Transport() {
    }

    Transport(LocalDateTime startTime, LocalDateTime endTime,
            Quantity quantity, ResidentInventoryItem source,ResidentInventoryItem target) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.quantity = quantity;
        this.source = source;
        this.target = target;
        this.status = TransportStatus.OPEN;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public ResidentInventoryItem getSource() {
        return source;
    }
        
    public ResidentInventoryItem getTarget() {
        return target;
    }
    
    public Product getProduct() {
        return source.getProduct();
    }

    public Location getFrom() {
        return source.getLocation();
    }
    
    public Location getTo() {
        return target.getLocation();
    }

    /**
     * @return the Quantity of the product to Transport
     */
    public Quantity getQuantity() {
        return quantity;
    }


    public TransportStatus getStatus() {
        return status;
    }

    public void complete() {
        status = TransportStatus.COMPLETE;
    }
}
