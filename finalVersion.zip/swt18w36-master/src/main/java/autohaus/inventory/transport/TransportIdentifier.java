package autohaus.inventory.transport;

import javax.persistence.Embeddable;
import org.salespointframework.core.SalespointIdentifier;

/**
 * Class for Type safety
 * 
 * @author Nico
 *
 */
@Embeddable
public final class TransportIdentifier extends SalespointIdentifier {
    private static final long serialVersionUID = -2082993472771683490L;

    public TransportIdentifier() {
        super();
    }

    public TransportIdentifier(String id) {
        super(id);
    }
}
