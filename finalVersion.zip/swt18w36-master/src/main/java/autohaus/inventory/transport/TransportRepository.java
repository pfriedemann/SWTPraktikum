package autohaus.inventory.transport;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.util.Streamable;


interface TransportRepository extends CrudRepository<Transport, TransportIdentifier> {
    public @Query("select i from Transport i where i.status = 'OPEN'")
    Streamable<Transport> findOpen();
    

}
