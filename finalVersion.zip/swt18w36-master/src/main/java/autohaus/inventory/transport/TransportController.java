package autohaus.inventory.transport;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.HashSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.salespointframework.quantity.Quantity;
import org.salespointframework.time.BusinessTime;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import autohaus.inventory.Location;
import autohaus.inventory.LocationRepository;
import autohaus.inventory.ResidentInventoryItem;

/**
 * Spring Controller for Transport related Views
 * 
 * @author Nico
 *
 */
@Controller
public class TransportController {
    private static final Logger log = LogManager.getLogger(TransportController.class);
    private final LocationRepository locationRepository;
    private final BusinessTime time;
    private final TransportService transportService;

    TransportController(LocationRepository locationRepository, TransportService transportService, BusinessTime time) {
        this.locationRepository = locationRepository;
        this.transportService = transportService;
        this.time = time;
    }

    /**
     * provides the Model for creating Transport Jobs. The jobs are saved by the
     * TransportRepository as Transport Objects these are used by the @class
     * TransportService
     * 
     * @param model
     * @param item
     * @return
     */
    @GetMapping("/transport/{item}")
    @PreAuthorize("hasAnyRole('ROLE_BOSS','ROLE_EMPLOYEE')")
    public String showInterface(Model model, @PathVariable ResidentInventoryItem item) {
        Iterable<Location> locations = locationRepository.findAll();
        HashSet<Location> filteredLocations = new HashSet<>();
        // filter source location out
        for (Location location : locations) {
            if (!location.equals(item.getLocation())) {
                filteredLocations.add(location);
            }
        }

        model.addAttribute("item", item);
        model.addAttribute("businessTime", time.getTime());
        model.addAttribute("locations", filteredLocations);

        TransportForm tf = new TransportForm();
        // insert current Date and Time as default values
        tf.setDateEnd(LocalDate.now().toString());
        LocalTime timeNow = LocalTime.now();
        tf.setTimeEnd(Integer.toString(timeNow.getHour()) + ":" + Integer.toString(timeNow.getMinute()));

        model.addAttribute("transportForm", tf);
        return "transport";
    }

    /**
     * Post Mapping for creating a Transport Job
     * 
     * @param item
     * @param timeEnd
     * @param dateEnd
     * @param amount
     * @param location
     * @return
     */
    @PostMapping("/transport/{item}")
    @PreAuthorize("hasAnyRole('ROLE_BOSS','ROLE_EMPLOYEE')")
    public String createTransport(@PathVariable ResidentInventoryItem item, @ModelAttribute TransportForm transportForm,
            RedirectAttributes ra) {
        LocalDateTime start = time.getTime();
        LocalDateTime end;
        String url = "redirect:/transport/" + item.getId().toString();
        try {
            end = LocalDateTime.parse(transportForm.getDateEnd() + "T" + transportForm.getTimeEnd());
        } catch (DateTimeParseException e) {
            ra.addFlashAttribute("popupError", "invalid time date format");
            return url;
        }
        if (start.isAfter(end)) {
            ra.addFlashAttribute("popupError", "error.timedate.endB4start");
            return url;
        }
        transportService.initiateTransport(item.getLocation(), transportForm.getLocation(), item.getProduct(),
                Quantity.of(transportForm.getAmount()), end);
        ra.addFlashAttribute("popupSuccess", "transport.created");
        return url;
    }

    /**
     * shows the transport history
     * 
     * @param model
     * @return
     */
    @GetMapping("/transport_history")
    @PreAuthorize("hasAnyRole('ROLE_BOSS','ROLE_EMPLOYEE')")
    public String showTransports(Model model) {
        model.addAttribute("transports", transportService.findAll());
        return "transport_history";
    }

    /**
     * forwards businesstime by one day
     * 
     * @return
     */
    @GetMapping("/timetravel")
    public String forwardTime() {
        final Duration duration = Duration.ofDays(1);
        time.forward(duration);
        log.info(String.format("forwared time by %s", duration.toString()));
        return "redirect:/";
    }

}
