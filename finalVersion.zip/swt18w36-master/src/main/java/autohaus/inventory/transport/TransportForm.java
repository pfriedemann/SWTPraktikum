package autohaus.inventory.transport;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import autohaus.inventory.Location;

/**
 * Form for submitting an Transport Job to TransportController
 * @author Nico
 *
 */

public class TransportForm {
    @NotNull
    @DateTimeFormat(pattern = "hh:mm")
    private String timeEnd;
    @NotNull
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private String dateEnd;
    @NotNull
    @Min(1)
    private long amount;

    @NotNull
    private Location location;
    
    public String getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(String timeEnd) {
        this.timeEnd = timeEnd;
    }

    public String getDateEnd() {
        return dateEnd;
    }

    public void setDateEnd(String dateEnd) {
        this.dateEnd = dateEnd;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

}
