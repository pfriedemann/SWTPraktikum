
package autohaus.inventory;

import autohaus.catalog.Auto;
import autohaus.catalog.AutoCatalog;

import org.salespointframework.core.DataInitializer;
import org.salespointframework.inventory.Inventory;
import org.salespointframework.inventory.InventoryItem;
import org.salespointframework.quantity.Quantity;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

/**
 * use MultiLocationInventory and MultiLocationInventoryInitializer
 *
 */
@Deprecated
@Component
@Order(20)
class InventoryInitializer implements DataInitializer {

    private final Inventory<InventoryItem> inventory;
    private final AutoCatalog autoCatalog;
    private final Quantity stock = Quantity.of(10);

    InventoryInitializer(Inventory<InventoryItem> inventory, AutoCatalog autoCatalog) {

        Assert.notNull(inventory, "must not be null!");
        Assert.notNull(autoCatalog, "must not be null!");

        this.inventory = inventory;
        this.autoCatalog = autoCatalog;
    }

    @Override
    public void initialize() {
        if (inventory.count() == 0) {
            for (Auto product : autoCatalog.findAll()) {
                inventory.save(new InventoryItem(product, stock));
            }
        }
    }
}
