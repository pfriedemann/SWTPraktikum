package autohaus.inventory;

import autohaus.catalog.Auto;
import autohaus.catalog.Auto.AutoType;
import autohaus.catalog.AutoCatalog;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.salespointframework.core.DataInitializer;
import org.salespointframework.quantity.Quantity;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component
public class MultiLocationInventoryInitializer implements DataInitializer {

    private static Logger log = LogManager.getLogger(MultiLocationInventory.class);
    private final AutoCatalog catalog;
    private final MultiLocationInventory inventory;
    private final LocationRepository locations;
    private final Quantity defaultQuantity = Quantity.of(10); 
    
    MultiLocationInventoryInitializer(AutoCatalog catalog, MultiLocationInventory inventory,
            LocationRepository locations) {
        this.catalog = catalog;
        this.inventory = inventory;
        this.locations = locations;
    }

    @Override
    public void initialize() {
        Assert.notNull(inventory, "Inventory must not be null!");
        Assert.notNull(catalog, "AutoCatalog must not be null!");

        //fill stock for all products at all locations with a quantity of 10
        //but exclude services
        if (inventory.count() == 0) {
            Streamable<Auto> products = Streamable.of(catalog.findAll()).filter( (Auto a) -> {
                return !a.getType().equals(AutoType.SERVICE);
            });
            products.forEach(product -> {
                locations.findAll().forEach(location -> {
                    inventory.save(new ResidentInventoryItem(product, defaultQuantity, location));
                });
            });
            log.info("filled empty inventory");
        }
    }
}
