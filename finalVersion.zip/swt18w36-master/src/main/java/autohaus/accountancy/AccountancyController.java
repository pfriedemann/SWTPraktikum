package autohaus.accountancy;

import java.security.KeyStore.Entry;
import java.util.*;

import static org.salespointframework.core.Currencies.EURO;

import javax.money.MonetaryAmount;

import org.salespointframework.accountancy.Accountancy;
import org.salespointframework.accountancy.AccountancyEntry;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import autohaus.user.UserManagement;

/**
 * Controller for getting accountants
 * @author Jingyan
 */

@Controller
public class AccountancyController {
	private final Accountancy accountancy;
	private final UserManagement userManagement;
	private final UserAccountManager userAccounts;
	private final PayrollController payroll;
		
	public AccountancyController(Accountancy accountancy, UserManagement userManagement, 
			UserAccountManager userAccounts,PayrollController payroll) {
		this.accountancy = accountancy;
		this.userManagement = userManagement;
		this.userAccounts = userAccounts;
		this.payroll = payroll;
	}
	
	
	/**
	 * Initializes the statistic diagram
	 *
	 */
	@PreAuthorize("hasRole('ROLE_BOSS')")
	@GetMapping("/statistic")
	String statistic(Model model) {
		
		String year = "Please select year";
		model.addAttribute("year", year);
		
		return "statistic";		
	}
	
	
	/**
	 * Calculate the accountants of specific year 
	 *
	 */
	HashMap<String, MonetaryAmount> getAccountans(int selYear){
		HashMap<String, MonetaryAmount> accountants = new HashMap<>();
		ArrayList<AccountancyEntry> entries = new ArrayList<>();
		accountancy.findAll().forEach(entries::add);
		
		for(AccountancyEntry entry : entries) {
				
			if(entry.getDate().get().getYear() == selYear) {
			
			int year = entry.getDate().get().getYear();
			int month = entry.getDate().get().getMonthValue();
			String time = month + "." + year;
					
			if (!accountants.containsKey(time)) {
				
				accountants.put(time, entry.getValue());
				
			}else {
				
				accountants.get(time).add(entry.getValue());
				}

			}
		}
		return accountants;
		
	}
	
	/**
	 * Pass the accountants data to revenue diagram
	 *
	 */
	@PreAuthorize("hasRole('ROLE_BOSS')")
	@PostMapping("/revenue")
	String showRevenue(@RequestParam("selYear") String year, Model model) {
		
		HashMap<String, MonetaryAmount> accountants = getAccountans(Integer.parseInt(year));
		
		List<String> timeList = new ArrayList<String>();
		List<String> amountList = new ArrayList<>();
		
		for(String t : accountants.keySet()) {
			timeList.add(t);
		}
		Collections.sort(timeList);
		
		for(int i=0; i<timeList.size(); i++) {
			amountList.add(accountants.get(timeList.get(i)).getNumber().toString());
		}

		
		String strX[] = timeList.toArray(new String[timeList.size()]);
		String strY[] = amountList.toArray(new String[amountList.size()]);
		
		model.addAttribute("strX",strX);
		model.addAttribute("strY", strY);
		model.addAttribute("year", year);
		
		return "statistic";
		
	}
	 
	/**
	 * Calculate the monthly total payments of specific year and pass the data to expense diagram
	 *
	 */
	@PreAuthorize("hasRole('ROLE_BOSS')")
	@PostMapping("/expense")
	String showExpense(Model model, @RequestParam("selYear") int year) {
		
		
		List<String> paymentList = new ArrayList<>();
		List<String> paydayList = new ArrayList<>();
		
	
		Map<Calendar, Double> totalPayments = new HashMap<>();
		Map<String, Map<Calendar, Double>> payments = payroll.getPayments();		
		Map<String, Double> totalPaymentStr = new HashMap<>();
		
		for(String user : payments.keySet()) {
			for(Calendar payday : payments.get(user).keySet()) {
				if(!totalPayments.containsKey(payday)){
					
					totalPayments.put(payday, payments.get(user).get(payday));
					
				}else {
					
					totalPayments.put(payday, totalPayments.get(payday)+payments.get(user).get(payday));
				}
			}
		}
		
		if(totalPayments != null) {
			for(Calendar payday : totalPayments.keySet()) {
				if(payday.get(Calendar.YEAR)==year) {
				String paydayStr = (payday.get(Calendar.MONTH)+1) + "." + payday.get(Calendar.YEAR);
				paydayList.add(paydayStr);
				totalPaymentStr.put(paydayStr, totalPayments.get(payday));
				}
			}
			Collections.sort(paydayList);
		
			for(int i=0; i< paydayList.size(); i++) {
			paymentList.add(totalPaymentStr.get(paydayList.get(i)).toString());
			}
		
		}

		
		String paymentString[] = paymentList.toArray(new String[paymentList.size()]);
		String paydayString[] = paydayList.toArray(new String[paydayList.size()]);
		model.addAttribute("paymentString", paymentString);
		model.addAttribute("paydayString", paydayString);
		model.addAttribute("year", year);
		
		return "statistic";
		
	}
}
