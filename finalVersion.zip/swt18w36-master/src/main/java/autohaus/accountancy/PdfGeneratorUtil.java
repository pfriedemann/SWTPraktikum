package autohaus.accountancy;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.lowagie.text.DocumentException;


/**
 * Method to generate a pdf
 * @author Jingyan
 *
 */
@Component
public class PdfGeneratorUtil {
	@Autowired
	private TemplateEngine templateEngine;
	public void createPdf(String templateName, Map map) throws IOException {
		Assert.notNull(templateName, "The templateName can not be null");
		Context ctx = new Context();
		if (map != null) {
		     Iterator itMap = map.entrySet().iterator();
		       while (itMap.hasNext()) {
			  Map.Entry pair = (Map.Entry) itMap.next();
		          ctx.setVariable(pair.getKey().toString(), pair.getValue());
			}
		}
		
		String html = templateEngine.process(templateName, ctx);
		
		OutputStream outputStream = new FileOutputStream("message.pdf");
		ITextRenderer renderer = new ITextRenderer();
		renderer.setDocumentFromString(html);
		renderer.layout();
		try {
			renderer.createPDF(outputStream);
		} catch (DocumentException e) {
			
			e.printStackTrace();
		}
		outputStream.close();
		
	
	}
}