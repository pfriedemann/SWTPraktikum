package autohaus.accountancy;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.web.LoggedIn;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import autohaus.user.User;
import autohaus.user.UserManagement;

/**
 * Controller for Payroll and receiving payment
 * @author Jingyan
 *
 */
@Controller
public class PayrollController {
	private final UserManagement userManagement;
	private Map<String, Map<Calendar, Double>> payments = new HashMap<>();
	private Calendar payday;
	private Map<Calendar, Double> salary = new HashMap<>();
	private static final int DAY = 12;
	@Autowired
	private PdfGeneratorUtil pdfGeneratorUtil;
	
	PayrollController(UserManagement userManagement) {
		this.userManagement = userManagement;
		
	}
	
	public Map<String, Map<Calendar, Double>> getPayments(){
		
		return payments;
	}
	
	/**
	 * show employee list and send payment option
	 *
	 */
	@PreAuthorize("hasRole('ROLE_BOSS')")
	@GetMapping("/payroll")
	String payroll(Model model) {
				
		Role role = Role.of("ROLE_EMPLOYEE");
		model.addAttribute("payroll", userManagement.findAll().filter(emp -> emp.hasRole(role)));
		
		return "payroll";
		
	}
	
	/**
	 * send specific month salary to employee 
	 *
	 */
	@PreAuthorize("hasRole('ROLE_BOSS')")
	@PostMapping("/doPayroll")
	String doPayroll(@RequestParam("payment") double payment, @RequestParam("uName") String username ,
			@RequestParam int selYear, @RequestParam int selMonth, RedirectAttributes ra) {		
	
		payday = Calendar.getInstance();	
		payday.set(Calendar.HOUR_OF_DAY, 0);
		payday.set(Calendar.MINUTE, 0);
		payday.set(Calendar.SECOND, 0);
		payday.set(Calendar.MILLISECOND, 0);
		payday.set(selYear, selMonth-1, DAY);
		
		if(payments.containsKey(username)) {
			Map<Calendar, Double> mySalary = payments.get(username);
			if(mySalary.containsKey(payday)) {
				ra.addFlashAttribute("message_duplicate", "Payroll already sent");				
			}else{
			mySalary.put(payday, payment);
			payments.put(username, mySalary);
			ra.addFlashAttribute("message_success", "Salary successfully sent");
			}
		}else {
			Map<Calendar, Double> mySalary = new HashMap<>();
			mySalary.put(payday, payment);
			payments.put(username, mySalary);
			ra.addFlashAttribute("message_success", "Salary successfully sent");
		}
				
		return "redirect:payroll";
	}
	
	/**
	 * show employee received salary
	 *
	 */
	@PreAuthorize("hasRole('ROLE_EMPLOYEE')")
	@GetMapping("/mypayroll")
	String showPayroll(Model model, @LoggedIn Optional<UserAccount> userAccount) {		
		
		
		userAccount.ifPresent(uAcc -> {
			User user = userManagement.findByUserAccount(uAcc);
			if(!(payments.get(uAcc.getUsername()) == null)) {
				
				salary = payments.get(uAcc.getUsername());
			}
			
			model.addAttribute("user", user);
			model.addAttribute("salary", salary);
			
			});
		
		return "mypayroll";
	}
	

	/**
	 * generate a downloadable pdf of specific month salary
	 *
	 */
	@GetMapping(value = "/greeting", produces="application/pdf")
	public void pdf(@LoggedIn Optional<UserAccount> userAccount, @RequestParam("payday") String payday, 
			@RequestParam("payment") Double payment, HttpServletResponse response) throws IOException {
		
		userAccount.ifPresent(uAcc -> {
			User user = userManagement.findByUserAccount(uAcc);
			String username = uAcc.getUsername();
			
			
		Map<String,String> data = new HashMap<String,String>();
	    data.put("name",username);
	    data.put("payday", payday);
	    data.put("payment", payment.toString());
	    System.out.println(data);
	    
	    try {
			pdfGeneratorUtil.createPdf("greeting",data);
		} catch (Exception e) {
			
			e.printStackTrace();
		} 
	    
	    try {
	       
	    	response.setContentType("application/pdf");
		    response.setHeader("Content-disposition", "attachment;filename=downloadpayroll.pdf");

	        File file = new File("message.pdf");
	        FileInputStream fileIn = new FileInputStream(file);
	        ServletOutputStream out = response.getOutputStream();

	        byte[] outputByte = new byte[(int)file.length()];
	        //copy binary contect to output stream
	        while(fileIn.read(outputByte, 0, (int)file.length()) != -1){
	        out.write(outputByte, 0, (int)file.length());
	        }
	    }catch (Exception e) {
			
			e.printStackTrace();
		} 
	    
	    
		});
	}
	
}
