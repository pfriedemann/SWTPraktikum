
package autohaus.order;

import autohaus.catalog.Auto;

import java.text.ParseException;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.websocket.server.PathParam;

import java.util.ArrayList;
import java.util.List;

import org.salespointframework.accountancy.Accountancy;
import org.salespointframework.accountancy.AccountancyEntry;
import org.salespointframework.catalog.Product;
import org.salespointframework.core.AbstractEntity;
import org.salespointframework.order.Cart;
import org.salespointframework.order.Order;
import org.salespointframework.order.OrderManager;
import org.salespointframework.order.OrderLine;
import org.salespointframework.order.OrderStatus;
import org.salespointframework.inventory.Inventory;
import org.salespointframework.inventory.InventoryItem;
import org.salespointframework.payment.Cash;
import org.salespointframework.quantity.Quantity;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.web.LoggedIn;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

/**
 * Controller for cart, orders and items.
 * @author Mina
 *
 */

@Controller
@SessionAttributes("cart")
class OrderController {
	
	private static final int minimal = 0;
	private static final int maximal = 5;
	private static final int not_less_than = 1;

	private InventoryItem inventoryProductId;

	private final OrderManager<Order> orderManager;
	private final Inventory<InventoryItem> inventory;
	private final Accountancy accountancy;

	OrderController(OrderManager<Order> orderManager, Inventory<InventoryItem> inventory, Accountancy accountancy) {

		Assert.notNull(orderManager, "OrderManager must not be null!");
		this.orderManager = orderManager;
		this.inventory = inventory;
		this.accountancy = accountancy;
	}
	
	
/**
 * Initializes a session cart for the customer
 *
 */

	@ModelAttribute("cart")
	Cart initializeCart() {
		return new Cart();
	}
	
/**
 * Shows all of the stock items to the administrator, particularly their name and quantity. 
 * More at the html.
 */
	
	@GetMapping("/items")
	@PreAuthorize("hasRole('ROLE_BOSS')")
	String showItems(Model model) {

		model.addAttribute("stock", inventory.findAll());

		return "items";
	}
	
/**
 * Adds an item with a given quantity to the cart of the customer.
 *
 */

	@PostMapping("/cart")
	String addAuto(@RequestParam("pid") Auto auto, @RequestParam("number") int number, @ModelAttribute Cart cart) {

	
		int amount = number <= minimal || number > maximal ? not_less_than : number;
		cart.addOrUpdateItem(auto, Quantity.of(amount));
				switch (auto.getType()) {
			case AUTO:
				return "redirect:autos";
			case SERVICE:
			default:
				return "redirect:services";
		}
	}

	@GetMapping("/cart")
	String basket() {
		return "cart";
	}
	
/**
 * Serves the purpose of "buying" an item from the customer perspective. 
 * In fact the order manager saves an open order, a new accountancy entry is produced and the item quantity is decreased.
 */

	@RequestMapping(value = "/cart/checkout", method = RequestMethod.POST)
	String buy(@ModelAttribute Cart cart, @LoggedIn Optional<UserAccount> userAccount){
		

	/*	return userAccount.map(account -> { */

			Order order = new Order(userAccount.get(), Cash.CASH);

			cart.addItemsTo(order);

			orderManager.save(order);
			
			for (OrderLine orderLine : order.getOrderLines()) {
			inventory.findByProductIdentifier(orderLine.getProductIdentifier()).get()
					.decreaseQuantity(orderLine.getQuantity());
			inventory.save(inventory.findByProductIdentifier(orderLine.getProductIdentifier()).get());
			} 
			
			cart.clear();
			
			AccountancyEntry aEntry = new AccountancyEntry(order.getTotalPrice());
			
			accountancy.add(aEntry); 
			

			return "redirect:/";
		/* }).orElse("redirect:/cart"); */
		
	}
	
/**
 * It removes a single, particular item from the customer's cart.
 * 
 */
	  
	@PostMapping("/remove/{autoId}")
	String removeAuto(@ModelAttribute Cart cart, @PathVariable String autoId) {
		cart.removeItem(autoId);
		return "redirect:/cart" ;
	}
	
/**
 * It removes all of the chosen items from the customer's cart before they are bought.
 * 
 */
	
	@PostMapping("/remove")
	String removeAll(@ModelAttribute Cart cart) {
		cart.clear();
		return "redirect:/cart" ;
	}
	
	
/**
 * Shows a page about the orders for the admin and employee's perspective.
 * 
 */
	@RequestMapping(value = "/orders", method = { RequestMethod.GET, RequestMethod.POST })
	@PreAuthorize("hasRole('ROLE_BOSS') || hasRole('ROLE_EMPLOYEE')")
	String orders1(Model model, HttpServletRequest request) throws ParseException {
		return "orders";
	}
	
/**
 * Serves the purpose for extending a unique order id and operating with it throughout an order lifecycle.
 * 
 */
	
	@RequestMapping(value = "/orders/{id}", method = RequestMethod.GET)
	@PreAuthorize("hasRole('ROLE_BOSS') || hasRole('ROLE_EMPLOYEE')")
	String orders2(Model model, @PathVariable("id") Order order) {
		model.addAttribute("id", order.getId());
		return "orders";
	}
	
/**
 * Shows all of the cancelled orders.
 * 
 */
	
	@GetMapping("/orders/cancelled")
	@PreAuthorize("hasRole('ROLE_BOSS') || hasRole('ROLE_EMPLOYEE')")
	String showCancelled(@RequestParam("id")Order order, Model model) {
        model.addAttribute("cancelledOrders", orderManager.findBy(OrderStatus.CANCELLED));
		return "cancelled";
	}
	
/**
 * Shows all of the open orders.
 * 
 */
	
	@GetMapping("/orders/open")
	@PreAuthorize("hasRole('ROLE_BOSS') || hasRole('ROLE_EMPLOYEE')")
    String showOpen(Model model) {
        model.addAttribute("openOrders", orderManager.findBy(OrderStatus.OPEN));

        return "open";
    }
	
/**
 * Shows all of the paid orders.
 * 
 */
	@GetMapping("/orders/paid")
	@PreAuthorize("hasRole('ROLE_BOSS') || hasRole('ROLE_EMPLOYEE')")
	String showPaid(@RequestParam("id")Order order, Model model) {
        model.addAttribute("paidOrders", orderManager.findBy(OrderStatus.PAID));
		return "paid";
	}
	
/**
 * Serves for "paying" an open order. The method also gives the unique order id to the next stage of the order lifecycle.
 * 
 */
	
	@RequestMapping(value= "orders/accept/{id}", method = RequestMethod.GET)
	String acceptOrder(@PathVariable("id") Order order) {
		
		orderManager.payOrder(order);		
		return "redirect:/orders/" + order.getId();
	}
	
/*	@GetMapping("/orders/completed")
	@PreAuthorize("hasRole('ROLE_BOSS') || hasRole('ROLE_EMPLOYEE')")
	String showCompleted(Model model) {
        model.addAttribute("completedOrders", orderManager.findBy(OrderStatus.COMPLETED));
		return "completed";
	}
	
	@RequestMapping(value= "/orders/deliver", method = RequestMethod.GET)
	@PreAuthorize("hasRole('ROLE_BOSS') || hasRole('ROLE_EMPLOYEE')")
	String deliverOrder(Order order){
		
		if (order.isPaid()) {
				orderManager.completeOrder(order);
			}
	
		return "redirect:/orders";
	
	} */
	

/**
 * Serves for "cancelling" an open order. The method also gives the unique order id to the next stage of the order lifecycle.
 * 
 */
	
	@GetMapping("orders/cancel/{id}")
	String cancelOrder(@PathVariable("id") Order order) {

			orderManager.cancelOrder(order);
		return "redirect:/orders/" + order.getId();
	}
	
/**
 * Serves for showing the details of a particular order.
 * Shows the user's nickname.
 * Shows the total price of the order.
 * Shows the name of the item.
 * Shows the description of the item and the minutes for executing a service.
 */
	
	@RequestMapping(value="orders/details/{id}")
	@PreAuthorize("hasRole('ROLE_BOSS') || hasRole('ROLE_EMPLOYEE')")
    String showDetails (@PathVariable("id") Order order, Model model){
        for (OrderLine orderLine : order.getOrderLines()) {
            model.addAttribute("customerId", order.getUserAccount().getId());
            model.addAttribute("price", order.getTotalPrice());
            model.addAttribute("name", inventory.findByProductIdentifier(orderLine.getProductIdentifier()).get().getProduct().getName());
			model.addAttribute("productInfo", inventory.findByProductIdentifier(orderLine.getProductIdentifier()).get().getProduct().toString());
        }	

        return "orderdetails";
    }
	
/**
 * Shows the bills details to a customer after their order has been executed by an employee.
 */
	
	@GetMapping("/bills")
    String showBills(@LoggedIn Optional<UserAccount> userAccount, Model model) {


		for (Order orders : orderManager.findBy(OrderStatus.PAID)){
			Iterable <Order> bills = orderManager.findBy(userAccount.get());
			
			model.addAttribute("bills", bills);
        
		}
		
	return "bills";
	}
		

	
}
