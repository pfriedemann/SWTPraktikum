
package autohaus.catalog;

import static org.salespointframework.core.Currencies.*;

import autohaus.catalog.Auto.AutoType;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.money.MonetaryAmount;
import javax.validation.Valid;

import javax.validation.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.javamoney.moneta.Money;
import org.salespointframework.inventory.Inventory;
import org.salespointframework.inventory.InventoryItem;
import org.salespointframework.quantity.Quantity;
import org.salespointframework.time.BusinessTime;
import org.springframework.boot.autoconfigure.cache.CacheAutoConfiguration;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
class CatalogController {

	private static final Quantity NONE = Quantity.of(0);

	private final AutoCatalog catalog;
	private final Inventory<InventoryItem> inventory;
	private final BusinessTime businessTime;
	private final double pDiscount = 0.01;

	CatalogController(AutoCatalog autoCatalog, Inventory<InventoryItem> inventory, BusinessTime businessTime) {

		this.catalog = autoCatalog;
		this.inventory = inventory;
		this.businessTime = businessTime;
	}
	

/**
 * Shows the car catalog.
 *
 */
	
	@GetMapping("/autos")
	String autoCatalog(Model model) {

		model.addAttribute("catalog", catalog.findByType(AutoType.AUTO));
		model.addAttribute("title", "catalog.auto.title");

		return "catalog";
	}
	
/**
 * Shows the services catalog.
 *
 */
	@GetMapping("/services")
	String serviceCatalog(Model model) {

		model.addAttribute("catalog", catalog.findByType(AutoType.SERVICE));
		model.addAttribute("title", "catalog.service.title");

		return "catalog";
	}
	
/**
 * Shows the accessories catalog.
 *
 */
	@GetMapping("/accessories")
	String accessoriesCatalog(Model model) {

		model.addAttribute("catalog", catalog.findByType(AutoType.ACCESSORIES));
		model.addAttribute("title", "catalog.accessories.title");

		return "catalog";
	}
	
/**
 * Shows the parts catalog.
 *
 */
	@GetMapping("/parts")
	String partsCatalog(Model model) {

		model.addAttribute("catalog", catalog.findByType(AutoType.PARTS));
		model.addAttribute("title", "catalog.parts.title");

		return "catalog";
	}
	
/**
 * Shows the reduced items.
 *
 */
	
	@GetMapping("/sales")
	String allItem(Model model) {
	
		model.addAttribute("allItems", catalog.findAll());
		
		return "sales";
		
	}
	
/**
 * Adjusts a discount on an item.
 *
 */
	
	@PostMapping("/discount")
	@PreAuthorize("hasRole('ROLE_BOSS') || hasRole('ROLE_EMPLOYEE')")
	String AddDiscount(@RequestParam("pid") Auto auto, @RequestParam("discount") int discount) {
		
		double priceToSet = auto.getPrice().getNumber().doubleValue() * discount * pDiscount;
		catalog.findById(auto.getId()).get().setPrice(Money.of(priceToSet, EURO));
		catalog.findById(auto.getId()).get().setRate(discount * pDiscount);
		catalog.save(auto);

		return "redirect:sales";
		
	}

/**
 * Shows the details of an item.
 *
 */
	
	@GetMapping("/auto/{auto}")
	String detail(@PathVariable Auto auto, Model model) {

		Optional<InventoryItem> item = inventory.findByProductIdentifier(auto.getId());
		Quantity quantity = item.map(InventoryItem::getQuantity).orElse(NONE);

		model.addAttribute("auto", auto);
		model.addAttribute("quantity", quantity);
		model.addAttribute("orderable", quantity.isGreaterThan(NONE));

		return "detail";
	}


}
