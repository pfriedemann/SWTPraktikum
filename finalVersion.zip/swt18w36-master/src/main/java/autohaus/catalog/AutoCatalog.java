
package autohaus.catalog;

import autohaus.catalog.Auto.AutoType;

import org.salespointframework.catalog.Catalog;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;


public interface AutoCatalog extends Catalog<Auto> {

	static final Sort DEFAULT_SORT = new Sort(Direction.DESC, "productIdentifier");

	Iterable<Auto> findByType(AutoType type, Sort sort);


	default Iterable<Auto> findByType(AutoType type) {
		return findByType(type, DEFAULT_SORT);
	}
}
