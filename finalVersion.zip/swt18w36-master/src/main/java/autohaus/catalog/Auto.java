
package autohaus.catalog;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

import org.javamoney.moneta.Money;
import org.salespointframework.catalog.Product;

/**
 * Serves the purpose for a central item class.
 * An Auto item is a Product, that has the additional features:
 * Enumeration AutoType for cars, services, parts and accessories;
 * minutes for a duration of a service
 * description for additional information about the item
 * rate for discount of a product
 */

@Entity
public class Auto extends Product {

	public static enum AutoType {
		AUTO, SERVICE, PARTS, ACCESSORIES;
	}

	
	private String model, image;
	private int minutes;
	private AutoType type;
	private String description;
	private double rate;


	@SuppressWarnings("unused")
	private Auto() {}

	public Auto(String name, String image, Money price, String model, AutoType type, int minutes, String description, double rate) {

		super(name, price);

		this.image = image;
		this.model = model;
		this.type = type;
		this.minutes = minutes;
		this.description = description;
		this.rate = rate;
	}

	public String getModel() {
		return model;
	}
	

	public String getImage() {
		return image;
	}

	public AutoType getType() {
		return type;
	}
	
	public int getMinutes(){
	return minutes;
	}
	
	public String getDescription(){
		return description;
	}
	
	public double getRate() {
		return rate;
	}
	
	public void setRate(double rate) {
		this.rate = rate;
	}
	
	@Override
	public String toString(){

	return model + ", " + description + ", " + minutes;
    }
	
}
