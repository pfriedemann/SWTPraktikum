
package autohaus.catalog;

import static org.salespointframework.core.Currencies.*;

import autohaus.catalog.Auto.AutoType;

import org.javamoney.moneta.Money;
import org.salespointframework.core.DataInitializer;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component
@Order(20)
class CatalogInitializer implements DataInitializer {

	private final AutoCatalog autoCatalog;
	private static final double porsche1 = 100000;
	private static final double porsche2 = 50000;
	private static final double porsche3 = 15000;
	private static final double porsche4 = 17000;
	private static final double service1 = 100;
	private static final double brille1 = 60;
	private static final double hat = 20;
	private static final double rad = 50;
	private static final double kit = 3000;
	private static final double abschleppen = 100;
	private static final double defaultRate = 1.00;
	private static final double discountRate1 = 0.80;
	private static final double discountRate2 = 0.50;
	

	CatalogInitializer(AutoCatalog autoCatalog) {

		Assert.notNull(autoCatalog, "AutoCatalog must not be null!");

		this.autoCatalog = autoCatalog;
	}
	
/**
 * Initializes all items of the Kracher catalog.
 *
 */

	@Override
	public void initialize() {

		if (autoCatalog.count() > 0) {
			return;
		}

		autoCatalog.save(new Auto("Pordi", "a1", Money.of(porsche1, EURO), "Panamera", AutoType.AUTO, 0, "Neu", defaultRate));
		autoCatalog.save(new Auto("Autoreparatur", "a2", Money.of(service1, EURO), "Pordi Autoreparatur", AutoType.SERVICE, 60, "Preis für eine Stunde", discountRate1));
		autoCatalog.save(new Auto("Sonnenbrille", "a3", Money.of(brille1, EURO), "Pordi Brille", AutoType.ACCESSORIES, 0, "Pordi Originalzubehör", defaultRate));
		autoCatalog.save(new Auto("Pordi", "a4", Money.of(porsche2, EURO), "911", AutoType.AUTO, 0, "Gebraucht", discountRate2));
		autoCatalog.save(new Auto("Pordi", "a5", Money.of(porsche3, EURO), "911", AutoType.AUTO, 12, "Leasing; Preis für 12 Monate", defaultRate));
		autoCatalog.save(new Auto("Pordi", "a6", Money.of(porsche4, EURO), "Panamera", AutoType.AUTO, 12, "Leasing; Preis für 12 Monate", defaultRate));
		autoCatalog.save(new Auto("Hut", "a7", Money.of(hat, EURO), "Pordi Hut", AutoType.ACCESSORIES, 0, "Pordi Originalzubehör", defaultRate));
		autoCatalog.save(new Auto("Ersatzreifen", "a8", Money.of(rad, EURO), "Pordi Autoreifen", AutoType.PARTS, 0, "Preis pro Reife", defaultRate));
		autoCatalog.save(new Auto("Ersatzteile Kit", "a9", Money.of(kit, EURO), "Pordi Ersatzteile", AutoType.PARTS, 0, "Preis für das gesamte Kit", defaultRate));
		autoCatalog.save(new Auto("Abschleppdienst", "a10", Money.of(abschleppen, EURO), "Pordi Abschleppdienst", AutoType.SERVICE, 60, "Preis für eine Stunde", defaultRate));

		
		
		
	}
}
