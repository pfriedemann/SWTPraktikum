package autohaus;

import org.salespointframework.EnableSalespoint;
import org.salespointframework.SalespointSecurityConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

@EnableSalespoint
public class AutohausApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutohausApplication.class, args);
	}

	@Configuration
	static class WebSecurityConfiguration extends SalespointSecurityConfiguration {

		@Override
		protected void configure(HttpSecurity http) throws Exception {
			http.authorizeRequests().antMatchers("/**").permitAll().and()
					.formLogin().loginProcessingUrl("/login").and()
					.logout().logoutUrl("/logout").logoutSuccessUrl("/");
		}
	}
	/**
	 * Enable Scheduling with the @Schedule annotation
	 * @author Nico
	 */
	@Configuration
	@EnableScheduling
	static class TaskSchedulerConfiguration{
	    
	}
}
