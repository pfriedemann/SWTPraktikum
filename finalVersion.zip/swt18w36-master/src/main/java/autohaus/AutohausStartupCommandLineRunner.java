package autohaus;

import java.util.Iterator;

import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

/**
 * shows information for testers when application is started with profile
 * crosstesting
 *
 */
@Component
@Profile("crosstesting")
public class AutohausStartupCommandLineRunner implements CommandLineRunner {

    private final UserAccountManager uam;

    public AutohausStartupCommandLineRunner(UserAccountManager uac) {
        this.uam = uac;
    }

    @Override
    public void run(String... args) throws Exception {
        final int stringBufferSize = 256;
        
        System.out.println("hello Tester\nUsers for Testing:");
        StringBuilder sb = new StringBuilder(stringBufferSize);
        for (UserAccount user : uam.findAll()) {
            sb.append(String.format("Username = %s ;Password = %s ;Roles = {", user.getUsername(), "123"));
            Iterator<Role> roles = user.getRoles().iterator();

            while (roles.hasNext()) {
                Role role = roles.next();
                sb.append(role.toString());
                if (roles.hasNext()) {
                    sb.append(',');
                }
            }
            sb.append("}\n");
        }
        System.out.println(sb.toString());
    }

}
