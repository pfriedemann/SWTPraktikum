package autohaus.user;

public interface AdminUserChangesForm extends UserChangesForm{
	String getRole();
}
