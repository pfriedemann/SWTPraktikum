
package autohaus.user;


import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;

@Entity
public class User {

	private @Id @GeneratedValue long id;

	@OneToOne(cascade=CascadeType.ALL)
	@ElementCollection(targetClass=String.class)
	private Address address;

	@OneToOne //
	private UserAccount userAccount;

	@SuppressWarnings("unused")
	private User() {}

	public User(UserAccount userAccount, Address address) {
		this.userAccount = userAccount;
		this.address = address;
	}

	public UserAccount getUserAccount() {
		return userAccount;
	}
	
	@Override
	public String toString(){

        return userAccount.getFirstname() + " " + userAccount.getLastname();
    }

	
	public long getId() {
		return id;
	}
	
	public boolean hasRole(Role role) {
		return userAccount.hasRole(role);
	}
	
	public boolean isDisabled() {
		return !userAccount.isEnabled();
	}
	
	public void setFirstname(String firstname) {
		userAccount.setFirstname(firstname);
	}
	
	public void setLastname(String lastname) {
		userAccount.setLastname(lastname);
	}
	
	public String getFirstname() {
		return userAccount.getFirstname();
	}
	
	public String getLastname() {
		return userAccount.getLastname();
	}
	
	//All about address

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	public void setAddressNumber(String number) {
		address.setNumber(number);
	}
	
	public void setAddressStreet(String street) {
		address.setStreet(street);
	}
	
	public void setAddressCity(String city) {
		address.setCity(city);
	}
	
	public String getAddressNumber(){
		return address.getNumber();
	}
	
	public String getAddressStreet(){
		return address.getStreet();
	}
	
	public String getAddressCity() {
		return address.getCity();
	}
	
	public String getAddressPostCode() {
		return address.getPostCode();
	}
	
	public void setAddressPostCode(String postCode) {
		address.setPostCode(postCode);
	}
	
	public String getAddressString() {
		return "" + address.getStreet() + " " + address.getNumber() + ", " + address.getPostCode() + " " + address.getCity();
	}
	

	
}
