package autohaus.user;

public interface UserChangesForm {
	String getUsername();  
	String getFirstname();
	String getLastname();
	String getPassword();
	String getNumber();
	String getStreet();
	String getCity();
	String getPostCode();	
}
