
package autohaus.user;

import java.util.Arrays;

import org.salespointframework.core.DataInitializer;
import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component
@Order(10)
class UserDataInitializer implements DataInitializer {

	private final UserAccountManager userAccountManager;
	private final UserRepository userRepository;

	UserDataInitializer(UserAccountManager userAccountManager, UserRepository userRepository) {

		Assert.notNull(userRepository, "UserRepository must not be null!");
		Assert.notNull(userAccountManager, "UserAccountManager must not be null!");

		this.userAccountManager = userAccountManager;
		this.userRepository = userRepository;         
	}


	@Override
	public void initialize() {

		
		if (userAccountManager.findByUsername("boss").isPresent()) {
			return;
		}

		UserAccount bossAccount = userAccountManager.create("boss", "123", Role.of("ROLE_BOSS"));
		Address bAddress = new Address("000000", "Bosstown", "Boss Street", "0");
		userAccountManager.save(bossAccount);
		User boss = new User(bossAccount,bAddress);

		Role customerRole = Role.of("ROLE_CUSTOMER");
		Role employeeRole = Role.of("ROLE_EMPLOYEE");

		UserAccount ua1 = userAccountManager.create("hans", "123", customerRole);
		UserAccount ua2 = userAccountManager.create("mia", "123", employeeRole);
		UserAccount ua3 = userAccountManager.create("carl", "123", employeeRole);
		
		Address a1 = new Address("01234", "Saarbruecken", "Gruenerstrasse", "36");
		Address a2 = new Address("11223", "Berlin", "Beyoncestrasse", "40");
		Address a3 = new Address("12345", "Dresden", "Beyoncestrasse", "40");
		
		User c1 = new User(ua1, a1);
		User c2 = new User(ua2, a2);
		User c3 = new User(ua3, a3);
		
		userRepository.saveAll(Arrays.asList(c1, c2, c3, boss));
	}
}
