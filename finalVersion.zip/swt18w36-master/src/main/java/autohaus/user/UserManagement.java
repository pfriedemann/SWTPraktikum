
package autohaus.user;

import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;


@Service
@Transactional
public class UserManagement {

	private final UserRepository users;
	private final UserAccountManager userAccounts;
	private static Role BOSS = Role.of("ROLE_BOSS");
	private static Role EMPLOYEE = Role.of("ROLE_EMPLOYEE");
	private static Role CUSTOMER = Role.of("ROLE_CUSTOMER");
	private static final int BOSS_NUMBER = 1;
	private static final int EMPLOYEE_NUMBER = 2;
	private static final int CUSTOMER_NUMBER = 3;

	UserManagement(UserRepository users, UserAccountManager userAccounts) {

		Assert.notNull(users, "UserRepository must not be null!");
		Assert.notNull(userAccounts, "UserAccountManager must not be null!");

		this.users = users;
		this.userAccounts = userAccounts;
	}


	public Streamable<User> findAll() {
		return Streamable.of(users.findAll());
	}
	
	public User findByUserAccount(UserAccount ua) {
		return users.findByUserAccount(ua);
	}
	
	private UserAccount newAccount;
	public User findByUsername(String username) {
		newAccount = null;
		userAccounts.findByUsername(username).ifPresent(ua ->{
			newAccount = ua;
		});
		return findByUserAccount(newAccount);			
	}
	
	public User createUser(RegistrationForm form) {
		Assert.notNull(form, "Registration form must not be null!");
		UserAccount userAccount = userAccounts.create(form.getUsername(), form.getPassword(), CUSTOMER);
		userAccount.setFirstname(form.getFirstname());
		userAccount.setLastname(form.getLastname());
		Address newAddress = new Address(form.getPostCode(),form.getCity(),form.getStreet(),form.getNumber());
		User newUser = new User(userAccount, newAddress);
		users.save(newUser);
		return newUser;
	}
	
	public User createUserByAdmin(AdminRegistrationForm form) {
		Assert.notNull(form, "Registration form must not be null!");
		UserAccount userAccount = userAccounts.create(form.getUsername(), form.getPassword(), Role.of(form.getRole()));
		userAccount.setFirstname(form.getFirstname());
		userAccount.setLastname(form.getLastname());
		Address newAddress = new Address(form.getPostCode(),form.getCity(),form.getStreet(),form.getNumber());
		User newUser = new User(userAccount, newAddress);
		users.save(newUser);
		return newUser;
	}
	
	public boolean disableUser(User user) {
		userAccounts.disable(user.getUserAccount().getId());
		return true;
	}
	
	public User adminChangesUserData(AdminUserChangesForm form, User user) {
		if(!form.getRole().isEmpty()) { 
			if(Integer.parseInt(form.getRole()) == BOSS_NUMBER) {
				user.getUserAccount().add(BOSS);
				if(user.hasRole(CUSTOMER)) {
					user.getUserAccount().remove(CUSTOMER);
				}
				if(user.hasRole(EMPLOYEE)) {
					user.getUserAccount().remove(EMPLOYEE);
				}
			}
			if(Integer.parseInt(form.getRole()) == EMPLOYEE_NUMBER) {
				user.getUserAccount().add(EMPLOYEE);
				if(user.hasRole(CUSTOMER)) {
					user.getUserAccount().remove(CUSTOMER);
				}
				if(user.hasRole(BOSS)) {
					user.getUserAccount().remove(BOSS);
				}
			}
			if(Integer.parseInt(form.getRole()) == CUSTOMER_NUMBER) {
				user.getUserAccount().add(CUSTOMER);
				if(user.hasRole(EMPLOYEE)) {
					user.getUserAccount().remove(EMPLOYEE);
				}
				if(user.hasRole(BOSS)) {
					user.getUserAccount().remove(BOSS);
				}
			}
			
			user.getUserAccount().add(Role.of(form.getRole()));			
		}
		
		return changeUserData(form,user);
	}
	
	public User changeUserData(UserChangesForm form, User user) {
		if(!form.getPassword().isEmpty()) { 
			userAccounts.changePassword(user.getUserAccount(), form.getPassword());
			}
		if(!form.getFirstname().isEmpty()) {
			user.setFirstname(form.getFirstname());
		}
		if(!form.getLastname().isEmpty()) {
			user.setLastname(form.getLastname());
		}
		if(!form.getStreet().isEmpty()) {
			user.setAddressStreet(form.getStreet());
		}
		if(!form.getNumber().isEmpty()) {
			user.setAddressNumber(form.getNumber());
		}
		if(!form.getCity().isEmpty()) {
			user.setAddressCity(form.getCity());
		}
		if(!form.getPostCode().isEmpty()) { 
			user.setAddressPostCode(form.getPostCode());
		}

		userAccounts.save(user.getUserAccount());
		users.save(user);
		return user;
	}
	
	
}
