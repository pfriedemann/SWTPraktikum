package autohaus.user;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/*
 * Each user has to specify an address for receiving packages(customer) and salary statement(worker)
 */
@Entity
public class Address {
	
	@Id
	@GeneratedValue
	private long id;
	
	private String city;
	private String street;
	private String postCode;
	
	//String because of house numbers like "1a"
	private String number;
	
	@SuppressWarnings("unused")
	public Address() {}
	
	public Address(String postCode, String city, String street, String number) {
		this.city = city;
		this.street = street;
		this.number = number;
		this.postCode = postCode;
	}
	
	public String getCity() {
		return city;
	}
	
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getStreet() {
		return street; 
	}
	
	public void setStreet(String street) {
		this.street = street;
	}
	
	
	public String getNumber() {
		return number;
	}
	
	public void setNumber(String number) {
		this.number = number;
	}
	
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	
	public String getPostCode() {
		return postCode;
	}
}
