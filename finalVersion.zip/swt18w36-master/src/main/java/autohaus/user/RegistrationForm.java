package autohaus.user;

import javax.validation.constraints.NotEmpty;

public interface RegistrationForm {


	@NotEmpty(message = "{RegistrationForm.username.NotEmpty}") //
	String getUsername();
	
	@NotEmpty(message = "{RegistrationForm.firstname.NotEmpty}") //
	String getFirstname();
	
	@NotEmpty(message = "{RegistrationForm.lastname.NotEmpty}") //
	String getLastname();

	@NotEmpty(message = "{RegistrationForm.password.NotEmpty}") //
	String getPassword();

	@NotEmpty(message = "{RegistrationForm.number.NotEmpty}") //
	String getNumber();
	
	@NotEmpty(message = "{RegistrationForm.street.NotEmpty}") //
	String getStreet();
	   
	@NotEmpty(message = "{RegistrationForm.city.NotEmpty}") //
	String getCity();
	
	@NotEmpty(message = "{RegistrationForm.postCode.NotEmpty}") //
	String getPostCode();
}
