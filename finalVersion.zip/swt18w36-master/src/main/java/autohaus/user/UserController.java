
package autohaus.user;

import java.util.Optional;

import javax.validation.Valid;

import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.web.LoggedIn;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.validation.Errors;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
class UserController {

	private boolean isAdmin;
	private final UserManagement userManagement;
	private String selectedUserId;

	UserController(UserManagement userManagement) {

		Assert.notNull(userManagement, "UserManagement must not be null!");

		this.userManagement = userManagement;
	}



	@GetMapping("/users")
	@PreAuthorize("hasRole('ROLE_BOSS')")
	String users(Model model) {
		model.addAttribute("userList", userManagement.findAll().filter(emp -> !emp.isDisabled()));
		return "users";
	}
	

	@GetMapping("/userProfile")
	String userProfile(Model model, @LoggedIn Optional<UserAccount> userAccount) {
		userAccount.ifPresent(uAcc -> {
			User user = userManagement.findByUserAccount(uAcc);
			model.addAttribute("user", user);
			});
		return "userProfile";
	} 
	
	@GetMapping("/customers")
	@PreAuthorize("hasRole('ROLE_BOSS') || hasRole('ROLE_EMPLOYEE')")
	String customers(Model model, CustomersForm form) {
		Role role = Role.of("ROLE_CUSTOMER");
		model.addAttribute("customers", userManagement.findAll().filter(emp -> emp.hasRole(role) && !emp.isDisabled()));
		model.addAttribute("form", form);  
		return "customers";    
	}  
	
	@PostMapping("/customers")
	@PreAuthorize("hasRole('ROLE_BOSS') || hasRole('ROLE_EMPLOYEE')")
	String postCustomers(Model model, @Valid CustomersForm form) {
		if(form.getDeleteCustomerUserAccountId() != null ) {
			selectedUserId = form.getDeleteCustomerUserAccountId();
			return "redirect:/adminUserDeletion"; 
		}
		if(form.getCustomerUserAccountId() != null) {
			selectedUserId = form.getCustomerUserAccountId();
			return "redirect:/adminUserChanges";
		}   
		return "redirect:/customers"; 
	}  
	
	@GetMapping("/employees")
	@PreAuthorize("hasRole('ROLE_BOSS')")
	String employees(Model model, EmployeesForm form) {
		Role role = Role.of("ROLE_EMPLOYEE");
		model.addAttribute("employees", userManagement.findAll().filter(emp -> emp.hasRole(role) && !emp.isDisabled()));
		model.addAttribute("form", form);
		return "employees";
	} 
	
	@PostMapping("/employees")
	@PreAuthorize("hasRole('ROLE_BOSS') || hasRole('ROLE_EMPLOYEE')")
	String postEmployees(Model model, @Valid EmployeesForm form) {
		if(form.getDeleteEmployeeUserAccountId() != null) {
			selectedUserId = form.getDeleteEmployeeUserAccountId();
			return "redirect:/adminUserDeletion"; 
		}
		if(form.getEmployeeUserAccountId() != null) {
			selectedUserId = form.getEmployeeUserAccountId();
			return "redirect:/adminUserChanges"; 
		}     
		return "redirect:/adminUserChanges"; 
	} 
	
	
	@GetMapping("/registration")
	String registration(Model model , RegistrationForm form) { 
		model.addAttribute("form", form);
		return "registration";
	}  
	
	@PostMapping("/registration")
	String postRegistration(@Valid RegistrationForm form, Errors result, Model model) {
		User user = userManagement.findByUsername(form.getUsername());
		if(user != null) { 
		result.rejectValue("username", "fields.username.notUnique",null, "An account with this username already exists.");
		model.addAttribute("form", form);
		return "registration";
		}
		if (result.hasErrors()) {
			return "registration";
		}		
		userManagement.createUser(form);
		return "redirect:/"; 
	}
	
	@GetMapping("/adminRegistration")
	String adminRegistration(Model model , AdminRegistrationForm form) {
		model.addAttribute("form", form);
		return "adminRegistration";
	}
	
	@PostMapping("/adminRegistration")
	String postAdminRegistration(@Valid AdminRegistrationForm form, Errors result, Model model) {
		User user = userManagement.findByUsername(form.getUsername());
		if(user != null) { 
		result.rejectValue("username", "fields.username.notUnique",null, "An account with this username already exists.");
		model.addAttribute("form", form);
		return "registration";
		}
		if (result.hasErrors()) {
			return "adminRegistration";
		}
		
		userManagement.createUserByAdmin(form);
		return "redirect:/";
	}
	
	@GetMapping("/userChanges")
	String userChanges(Model model , UserChangesForm form, @LoggedIn Optional<UserAccount> userAccount) {
		userAccount.ifPresent(uAcc -> {
			User user = userManagement.findByUserAccount(uAcc);
			model.addAttribute("user", user);
			});
		model.addAttribute("form", form);
		return "userChanges";
	}
	     
	@PostMapping("/userChanges")
	String postUserChanges(UserChangesForm form, @LoggedIn Optional<UserAccount> userAccount) {
		userAccount.ifPresent(uAcc -> {
			User user = userManagement.findByUserAccount(uAcc);
			userManagement.changeUserData(form, user);
			});
		                                      
		return "redirect:/userProfile";
	}  
	
	@GetMapping("/adminUserChanges")
	String adminUserChanges(Model model, AdminUserChangesForm form) {
		User user = userManagement.findByUsername(selectedUserId);
		String userRole = "";
		if(user.hasRole(Role.of("ROLE_ADMIN"))) {
			userRole = "Admin";
		}
		if(user.hasRole(Role.of("ROLE_CUSTOMER"))) {
			userRole = "Customer";
		}
		if(user.hasRole(Role.of("ROLE_EMPLOYEE"))) {
			userRole = "Employee";	
		}
		model.addAttribute("userRole", userRole); 
		model.addAttribute("user", user);	
		model.addAttribute("form", form);
		return "adminUserChanges";
	}
	
	@PostMapping("/adminUserChanges")
	String postAdminUserChanges(AdminUserChangesForm form, @LoggedIn Optional<UserAccount> userAccount) {			
		User user = userManagement.findByUsername(selectedUserId);
		userManagement.adminChangesUserData(form, user);
		userAccount.ifPresent(uAcc -> {
			if(uAcc.hasRole(Role.of("ROLE_BOSS"))) {
				isAdmin = true;			
			} else { isAdmin = false;}
		}); 
		if(isAdmin == true) {
			return "redirect:/users";
		} else {
			return "redirect:/customers";
		}
	}     
	
	@GetMapping("/userDeletionRequest")
	String deleteUserRequest(Model model, @LoggedIn Optional<UserAccount> userAccount) {
		return "userDeletionRequest"; 
	}
	
	@GetMapping("/userDeletion")
	String deleteUser( Model model, @LoggedIn Optional<UserAccount> userAccount){
		userAccount.ifPresent(uAcc -> {
			User user = userManagement.findByUserAccount(uAcc);
			userManagement.disableUser(user);
			});
		
		return "userDeletion"; 
	}
	
	@GetMapping("/adminUserDeletion")
	String adminUserDeletion( Model model){
		User user = userManagement.findByUsername(selectedUserId);
		model.addAttribute("user", user);
		return "adminUserDeletion"; 
	}
	
	@PostMapping("/adminUserDeletion")
	String postAdminUserDeletion(UserChangesForm form) {
		User user = userManagement.findByUsername(selectedUserId);
		userManagement.disableUser(user);
		
		return "redirect:/users";
	}  
	
	
}
