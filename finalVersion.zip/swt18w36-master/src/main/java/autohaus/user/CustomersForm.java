package autohaus.user;

public interface CustomersForm {
	String getCustomerUserAccountId();
	String getDeleteCustomerUserAccountId();
}
