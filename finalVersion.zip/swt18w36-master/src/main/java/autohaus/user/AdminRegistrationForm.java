package autohaus.user;

import javax.validation.constraints.NotEmpty;

public interface AdminRegistrationForm extends RegistrationForm {

	@NotEmpty(message = "{AdminRegistrationForm.role.NotEmpty}") //
	String getRole();
	
}
