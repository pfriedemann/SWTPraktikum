package autohaus.user;

public interface EmployeesForm {
	String getEmployeeUserAccountId();
	String getDeleteEmployeeUserAccountId();
}
