
package autohaus.catalog;

import static org.assertj.core.api.Assertions.*;

import autohaus.AbstractIntegrationTest;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;

class CatalogControllerIntegrationTest extends AbstractIntegrationTest {

	@Autowired CatalogController controller;
	@Test
	@SuppressWarnings("unchecked")
	public void sampleControllerIntegrationTest() {

		Model model = new ExtendedModelMap();

		String returnedView = controller.autoCatalog(model);

		assertThat(returnedView).isEqualTo("catalog");
	}
}
