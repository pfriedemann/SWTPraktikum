
package autohaus.catalog;

import static org.assertj.core.api.Assertions.*;

import autohaus.AbstractIntegrationTest;
import autohaus.catalog.Auto;
import autohaus.catalog.Auto.AutoType;
import autohaus.catalog.AutoCatalog;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;


class AutoCatalogIntegrationTests extends AbstractIntegrationTest {

	@Autowired AutoCatalog catalog;

	@Test
	void autosDontHaveAnyCategoriesAssigned() {

		for (Auto auto : catalog.findByType(AutoType.AUTO)) {
			assertThat(auto.getCategories()).isEmpty();
		}
	}
}
