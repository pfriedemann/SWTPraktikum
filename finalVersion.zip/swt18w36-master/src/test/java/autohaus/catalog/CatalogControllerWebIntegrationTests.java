
package autohaus.catalog;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import autohaus.AbstractWebIntegrationTest;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

class CatalogControllerWebIntegrationTests extends AbstractWebIntegrationTest {

	@Autowired CatalogController controller;
	@Test
	void sampleMvcIntegrationTest() throws Exception {

		mvc.perform(get("/autos")). //
				andExpect(status().isOk()).//
				andExpect(model().attribute("catalog", is(not(emptyIterable()))));
	}
}
