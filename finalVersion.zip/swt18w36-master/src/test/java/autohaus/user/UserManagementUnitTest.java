package autohaus.user;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.Mock;
import org.salespointframework.useraccount.UserAccountManager;
import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountIdentifier;

import static org.mockito.Mockito.*;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(Lifecycle.PER_CLASS)
public class UserManagementUnitTest {
		private String username;
		private UserAccountManager userAccounts;
		private UserRepository users;
		private User testUser;
		private UserAccount testUserAccount;
		private RegistrationForm testForm;
		private AdminRegistrationForm testAdminForm;
		private AdminUserChangesForm testAdminChangesForm;
		private AdminUserChangesForm testAdminChangesForm2;
		private AdminUserChangesForm testAdminChangesForm3;
		private static String testCity = "testCity";
		private static String testStreet = "Test Street";
		private static String testPostCode = "123456";
		private static String testNumber = "12a";
		private static String testFirstname = "firstname";
		private static String testLastname = "lastname";
		private static String testRole = "ROLE_CUSTOMER";
		private static String testUsername = "username";
		private static String testPassword = "123";
		private static UserAccountIdentifier testId;
		
		
		
		private UserManagement testManagement;

		
	 @BeforeAll
	    void setUp(){
		 username = "testUsername";
		 userAccounts = mock(UserAccountManager.class);
		 users = mock(UserRepository.class);
		 testUser = mock(User.class);
		 testUserAccount = mock(UserAccount.class);
		 testForm = mock(RegistrationForm.class);
		 testAdminForm = mock(AdminRegistrationForm.class);
		 testAdminChangesForm = mock(AdminUserChangesForm.class);
		 testAdminChangesForm2 = mock(AdminUserChangesForm.class);
		 testAdminChangesForm3 = mock(AdminUserChangesForm.class);
		 when(userAccounts.findByUsername(username)).thenReturn(Optional.of(testUserAccount));
		 when(userAccounts.create(testUsername, testPassword, Role.of(testRole))).thenReturn(testUserAccount);
		 when(userAccounts.save(testUserAccount)).thenReturn(testUserAccount);
		 when(testUser.getUserAccount()).thenReturn(testUserAccount);
		 
		 when(users.findByUserAccount(testUserAccount)).thenReturn(testUser);
		 when(testForm.getCity()).thenReturn(testCity);
		 when(testForm.getStreet()).thenReturn(testStreet);
		 when(testForm.getNumber()).thenReturn(testNumber);
		 when(testForm.getPostCode()).thenReturn(testPostCode);
		 when(testForm.getFirstname()).thenReturn(testFirstname);
		 when(testForm.getLastname()).thenReturn(testLastname);
		 when(testForm.getUsername()).thenReturn(testUsername);
		 when(testForm.getPassword()).thenReturn(testPassword);
		 
		 when(testAdminForm.getCity()).thenReturn(testCity);
		 when(testAdminForm.getStreet()).thenReturn(testStreet);
		 when(testAdminForm.getNumber()).thenReturn(testNumber);
		 when(testAdminForm.getPostCode()).thenReturn(testPostCode);
		 when(testAdminForm.getFirstname()).thenReturn(testFirstname);
		 when(testAdminForm.getLastname()).thenReturn(testLastname);
		 when(testAdminForm.getUsername()).thenReturn(testUsername);
		 when(testAdminForm.getPassword()).thenReturn(testPassword);
		 when(testAdminForm.getRole()).thenReturn(testRole);
		 
		 when(testAdminChangesForm.getCity()).thenReturn(testCity);
		 when(testAdminChangesForm.getStreet()).thenReturn(testStreet);
		 when(testAdminChangesForm.getNumber()).thenReturn(testNumber);
		 when(testAdminChangesForm.getPostCode()).thenReturn(testPostCode);
		 when(testAdminChangesForm.getFirstname()).thenReturn(testFirstname);
		 when(testAdminChangesForm.getLastname()).thenReturn(testLastname);
		 when(testAdminChangesForm.getUsername()).thenReturn(testUsername);
		 when(testAdminChangesForm.getPassword()).thenReturn(testPassword);
		 when(testAdminChangesForm.getRole()).thenReturn("1");
		 
		 when(testAdminChangesForm2.getCity()).thenReturn(testCity);
		 when(testAdminChangesForm2.getStreet()).thenReturn(testStreet);
		 when(testAdminChangesForm2.getNumber()).thenReturn(testNumber);
		 when(testAdminChangesForm2.getPostCode()).thenReturn(testPostCode);
		 when(testAdminChangesForm2.getFirstname()).thenReturn(testFirstname);
		 when(testAdminChangesForm2.getLastname()).thenReturn(testLastname);
		 when(testAdminChangesForm2.getUsername()).thenReturn(testUsername);
		 when(testAdminChangesForm2.getPassword()).thenReturn(testPassword);
		 when(testAdminChangesForm2.getRole()).thenReturn("2");
		 
		 when(testAdminChangesForm3.getCity()).thenReturn(testCity);
		 when(testAdminChangesForm3.getStreet()).thenReturn(testStreet);
		 when(testAdminChangesForm3.getNumber()).thenReturn(testNumber);
		 when(testAdminChangesForm3.getPostCode()).thenReturn(testPostCode);
		 when(testAdminChangesForm3.getFirstname()).thenReturn(testFirstname);
		 when(testAdminChangesForm3.getLastname()).thenReturn(testLastname);
		 when(testAdminChangesForm3.getUsername()).thenReturn(testUsername);
		 when(testAdminChangesForm3.getPassword()).thenReturn(testPassword);
		 when(testAdminChangesForm3.getRole()).thenReturn("3");
		 
		 
		 testManagement = new UserManagement(users, userAccounts);	 
	 }
	 
	 @Test
	 void testUserManagement() {
		 assertTrue(testManagement.findByUsername(username).equals(testUser));
		 Assertions.assertNotNull(testManagement.createUser(testForm));
		 Assertions.assertNotNull(testManagement.createUserByAdmin(testAdminForm));
		 Assertions.assertNotNull(testManagement.adminChangesUserData(testAdminChangesForm, testUser));
		 Assertions.assertNotNull(testManagement.adminChangesUserData(testAdminChangesForm2, testUser));
		 Assertions.assertNotNull(testManagement.adminChangesUserData(testAdminChangesForm3, testUser));	 
	 }
	
}
