package autohaus.user;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@TestInstance(Lifecycle.PER_CLASS)
public class ControllerIntegrationTest {
	
	private UserController userController;
	private EmployeesForm empForm;
	private CustomersForm cuForm;
	private EmployeesForm empForm2;
	private CustomersForm cuForm2;
	private UserManagement userManagement;
	private Model model;
	private RegistrationForm regForm;
	private Errors err;
	
	@BeforeAll
	public void setUp() {
		userManagement = mock(UserManagement.class);
		empForm = mock(EmployeesForm.class);
		empForm2 = mock(EmployeesForm.class);
		cuForm = mock(CustomersForm.class);
		cuForm2 = mock(CustomersForm.class);
		model = mock(Model.class);
		regForm = mock(RegistrationForm.class);
		userController = new UserController(userManagement);
		err = mock(Errors.class);
		
		when(cuForm.getDeleteCustomerUserAccountId()).thenReturn("hans");
		when(cuForm.getCustomerUserAccountId()).thenReturn(null);
		when(cuForm2.getCustomerUserAccountId()).thenReturn("hans");
		when(cuForm2.getDeleteCustomerUserAccountId()).thenReturn(null);
		
		
		when(empForm.getDeleteEmployeeUserAccountId()).thenReturn("mia");
		when(empForm.getEmployeeUserAccountId()).thenReturn(null);
		when(empForm2.getEmployeeUserAccountId()).thenReturn("mia");
		when(empForm2.getDeleteEmployeeUserAccountId()).thenReturn(null);
		
		when(regForm.getUsername()).thenReturn("");
		when(userManagement.findByUsername(regForm.getUsername())).thenReturn(null);
		when(err.hasErrors()).thenReturn(true);
		
		
	}
	
	@Test
	public void testPostCustomers() {
		assertTrue(userController.postCustomers(model, cuForm).equals("redirect:/adminUserDeletion"));
		assertTrue(userController.postCustomers(model, cuForm2).equals("redirect:/adminUserChanges"));
	}
	
	@Test
	public void testPostEmployees() {
		assertTrue(userController.postEmployees(model, empForm).equals("redirect:/adminUserDeletion"));
		assertTrue(userController.postEmployees(model, empForm2).equals("redirect:/adminUserChanges"));
	}
	
	@Test
	public void testPostRegistration() {
		assertTrue(userController.postRegistration(regForm, err, model).equals("registration"));
	}

}
