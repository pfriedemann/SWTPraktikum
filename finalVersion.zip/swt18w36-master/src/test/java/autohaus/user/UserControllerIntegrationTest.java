package autohaus.user;

import autohaus.AbstractWebIntegrationTest;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.springframework.boot.test.context.SpringBootTest;


@TestInstance(Lifecycle.PER_CLASS)
@SpringBootTest
public class UserControllerIntegrationTest extends AbstractWebIntegrationTest {
	
    @Test
    public void testUsers() {
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get("/users").with(user("boss").roles("BOSS"))).andExpect(status().isOk())
                    .andExpect(view().name("users"));// 
        });
    }
    
    @Test
    public void testCustomers() {
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get("/customers").with(user("boss").roles("BOSS"))).andExpect(status().isOk())
                    .andExpect(view().name("customers"));// 
        });
    }
    
    @Test
    public void testEmployees() {
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get("/employees").with(user("boss").roles("BOSS"))).andExpect(status().isOk())
                    .andExpect(view().name("employees"));// 
        });
    }
    
    @Test
    public void testadminRegistration() {
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get("/adminRegistration").with(user("boss").roles("BOSS"))).andExpect(status().isOk())
                    .andExpect(view().name("adminRegistration"));// 
        });
    }
    
    @Test
    public void testUserProfile() {
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get("/userProfile").with(user("boss").roles("BOSS"))).andExpect(status().isOk())
                    .andExpect(view().name("userProfile"));// 
        });
    }
    
    @Test
    public void testRegistration() {
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get("/registration").with(user("boss").roles("BOSS"))).andExpect(status().isOk())
                    .andExpect(view().name("registration"));// 
        });
    }
    
    @Test
    public void testUserChanges() {
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get("/userChanges").with(user("boss").roles("BOSS"))).andExpect(status().isOk())
                    .andExpect(view().name("userChanges"));// 
        });
    }
    
    @Test
    public void testUserDeletionRequest() {
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get("/userDeletionRequest").with(user("boss").roles("BOSS"))).andExpect(status().isOk())
                    .andExpect(view().name("userDeletionRequest"));// 
        });
    }
    
    @Test
    public void testUserDeletion() {
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get("/userDeletion").with(user("boss").roles("BOSS"))).andExpect(status().isOk())
                    .andExpect(view().name("userDeletion"));// 
        });
    }
    
}



