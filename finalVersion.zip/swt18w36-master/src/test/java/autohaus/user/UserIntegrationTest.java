package autohaus.user;

import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.beans.factory.annotation.Autowired;

import autohaus.AbstractIntegrationTest;

public class UserIntegrationTest extends AbstractIntegrationTest{
    
    private UserRepository users;
    private UserAccountManager userAccountManager;

    @Autowired
    private void setUserAccountManager(UserAccountManager userAccounts) {
        this.userAccountManager = userAccounts;
    }

    @Autowired
    private void setUserRepository(UserRepository users) {
        this.users = users;
    }


    @Test
    public void testBossUser() {
        Optional<UserAccount> userAccount = userAccountManager.findByUsername("boss");
        Assertions.assertTrue(userAccount.isPresent(), "userAccount for boss not found");
        userAccount.ifPresent(uAcc -> {
			User user = users.findByUserAccount(uAcc);
			Assertions.assertTrue(user!= null, "User for userAccount boss not found");
			Assertions.assertFalse(user.getAddressStreet().isEmpty(), "The user has no street");
			Assertions.assertFalse(user.getAddressNumber().isEmpty(), "The user has no number");
			Assertions.assertFalse(user.getAddressPostCode().isEmpty(), "The user has no post code");
			Assertions.assertFalse(user.getAddressCity().isEmpty(), "The user has no city");
			//Assertions.assertTrue(user.getFirstname().isEmpty(),"boss has a firstname?");
			//Assertions.assertTrue(user.getLastname().isEmpty(),"boss has a lastname?");
        });
    }

}
