package autohaus.order;

import java.util.Iterator;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.springframework.data.util.Streamable;
import autohaus.AbstractIntegrationTest;
import autohaus.catalog.Auto;
import autohaus.catalog.Auto.AutoType;
import autohaus.catalog.AutoCatalog;
import org.salespointframework.accountancy.Accountancy;
import static org.salespointframework.core.Currencies.*;
import org.salespointframework.quantity.Quantity;
import org.salespointframework.payment.Cash;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.BeforeAll;
import org.salespointframework.order.Cart;
import org.salespointframework.order.CartItem;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import autohaus.user.User;
import org.salespointframework.useraccount.Role;
import autohaus.user.Address;
import org.salespointframework.inventory.Inventory;
import org.salespointframework.inventory.InventoryItem;
import org.salespointframework.order.Cart;
import org.salespointframework.order.CartItem;
import org.salespointframework.order.Order;
import org.salespointframework.order.OrderManager;

import org.javamoney.moneta.Money;

public class OrderControllerIntegrationTest extends AbstractIntegrationTest {
	
	private OrderManager<Order> orderManager;
	private UserAccountManager userAccountManager;
	private OrderController orderController;
	private Inventory<InventoryItem> inventory;
	private Accountancy accountancy;
	private double porsche1 = 100.000;
	Optional<UserAccount> testUserAccount;
	
	@Autowired
	private void setAccountancy(Accountancy accountancy){
		this.accountancy = accountancy;
	}
	
	@Autowired
    private void setOrderManager(OrderManager<Order> orderManager) {
        this.orderManager = orderManager;
    }

	@Autowired
    private void setUserAccountManager(UserAccountManager userAccountManager) {
        this.userAccountManager = userAccountManager;
    }
	
	@Autowired
    private void setOrderController(OrderController orderController) {
        this.orderController = orderController;
    }
	
	@Autowired
    private void setInventory(Inventory<InventoryItem> inventory) {
        this.inventory = inventory;
    }
	
		
	@Test
	public void testAddAuto(){
		Cart cart = new Cart();
		Assertions.assertTrue(cart.isEmpty());
	}
	
	@Test
	public void testRemoveAuto(){
		Cart cart = new Cart();
		CartItem cartItem = cart.addOrUpdateItem((new Auto("Pordi", "a1", Money.of(porsche1, EURO), "Panamera", AutoType.AUTO, 0, "Neu", 1.00)), Quantity.of(2));
		Assertions.assertEquals("redirect:/cart", "redirect:/cart", orderController.removeAuto(cart, cartItem.getId()));
	}
	
	
	@Test 
	public void testRemove(){
		Cart cart = new Cart();
		CartItem cartItem = cart.addOrUpdateItem((new Auto("Pordi", "a1", Money.of(porsche1, EURO), "Panamera", AutoType.AUTO, 0, "Neu", 1.00)), Quantity.of(2));
		Assertions.assertEquals("redirect:/cart", "redirect:/cart", orderController.removeAll(cart));
		Assertions.assertTrue(cart.isEmpty());
	}
	/**
	
	@Test
	public void testBuy(){
		
		Cart cart = new Cart();
		cart.addOrUpdateItem((new Auto("Pordi", "a1", Money.of(porsche1, EURO), "Panamera", AutoType.AUTO, 0, "Neu", 1.00)), Quantity.of(3));
		
		orderController.buy(cart, testUserAccount);
		Assertions.assertTrue(cart.isEmpty());
	}
	
	
	@Test
	public void testCancelOrder(){
		Order order;

		order = new Order(testUserAccount.get(), Cash.CASH);
		orderManager.save(order);
		Assertions.assertEquals("redirect:/orders/" + order.getId(), "redirect:/orders/" + order.getId(), orderController.cancelOrder(order));
	}
	
	
	@Test
	public void testAcceptOrder(){
		Order order;

		order = new Order(testUserAccount.get(), Cash.CASH);
		orderManager.save(order);
		Assertions.assertEquals("redirect:/orders/" + order.getId(), "redirect:/orders/" + order.getId(), orderController.acceptOrder(order));
	}
 **/
}