
package autohaus.order;

import static org.hamcrest.CoreMatchers.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import autohaus.AbstractWebIntegrationTest;

import org.junit.jupiter.api.Test;

class OrderControllerWebIntegrationTest extends AbstractWebIntegrationTest {
	
	
	/**
	 * Trying to access a secured resource should result in a redirect to the login page.
	 * 
	 * 
	 */

	@Test
	void redirectsToLoginPageForSecuredResource() throws Exception {

		mvc.perform(get("/orders")).//
				andExpect(status().isFound()).//
				andExpect(header().string("Location", endsWith("/login")));
	}

	/**
	 * Trying to access the orders as boss should result in the page being rendered.
	 * 
	 * 
	 */
	
	@Test
	void returnsModelAndViewForSecuredUriAfterAuthentication() throws Exception {

		mvc.perform(get("/orders").with(user("boss").roles("BOSS"))).//
				andExpect(status().isOk()).//
				andExpect(view().name("orders"));
				
		mvc.perform(get("/orders").with(user("employee").roles("EMPLOYEE"))).//
				andExpect(status().isOk()).//
				andExpect(view().name("orders"));
	}
}
