package autohaus;

import org.assertj.core.api.Assertions;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import autohaus.ApplicationController;

public class ApplicationControllerIntegrationTest extends AbstractIntegrationTest{

	private ApplicationController controller;
	
	@Autowired
	private void setController(ApplicationController controller){
		this.controller = controller;
	}
	
	@Test
	public void controllerTest() {
		String returnedView = controller.index();
		
		Assertions.assertThat(returnedView).isEqualTo("welcome");
	}
}
