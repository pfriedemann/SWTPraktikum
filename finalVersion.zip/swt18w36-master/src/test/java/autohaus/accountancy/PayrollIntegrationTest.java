package autohaus.accountancy;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.salespointframework.useraccount.UserAccount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import autohaus.AbstractIntegrationTest;

public class PayrollIntegrationTest extends AbstractIntegrationTest{
	
	private RedirectAttributes ra;
	private Optional<UserAccount> user;
	private HttpServletResponse response;
	@Autowired
	private PayrollController payrollController;


	
	@BeforeAll
    public void setUp() {
		ra = mock(RedirectAttributes.class);
	}
		
	@Test
	@WithMockUser(username="boss",roles={"BOSS"})
	public void testPayments(){
		payrollController.doPayroll(5000, "mia", 2019, 02, ra);
		assertNotNull(payrollController.getPayments(), "should not be null");
	
	}
		
}
