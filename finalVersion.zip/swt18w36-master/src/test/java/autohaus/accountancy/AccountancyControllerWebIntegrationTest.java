package autohaus.accountancy;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import autohaus.AbstractWebIntegrationTest;

public class AccountancyControllerWebIntegrationTest extends AbstractWebIntegrationTest{
	
	@Test
    public void testStatistic() {
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get("/statistic").with(user("boss").roles("BOSS"))).andExpect(status().isOk())
                    .andExpect(view().name("statistic"));
        });
    }
	
}
