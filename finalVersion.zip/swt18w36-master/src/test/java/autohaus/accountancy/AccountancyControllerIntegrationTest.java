package autohaus.accountancy;

import static org.mockito.Mockito.mock;
import static org.salespointframework.core.Currencies.EURO;

import java.sql.Date;
import java.util.Calendar;

import org.javamoney.moneta.Money;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.salespointframework.accountancy.Accountancy;
import org.salespointframework.accountancy.AccountancyEntry;
import org.salespointframework.catalog.Product;
import org.salespointframework.order.Cart;
import org.salespointframework.order.Order;
import org.salespointframework.payment.Cash;
import org.salespointframework.quantity.Quantity;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import autohaus.AbstractIntegrationTest;
import autohaus.order.OrderControllerIntegrationTest;


public class AccountancyControllerIntegrationTest extends AbstractIntegrationTest{

	private Order order;
	private UserAccount user;
	private Product product;
	private final Quantity quantity = Quantity.of(100);
	private Model model;
	private RedirectAttributes ra;
	Calendar cal = Calendar.getInstance();
	int month = cal.get(Calendar.MONTH)+1;
	int year = cal.get(Calendar.YEAR);
	String pDate = month + "." + year;
	
	@Autowired
    private Accountancy accountancy;
	@Autowired
	private AccountancyController accountancyController;
	@Autowired
	private PayrollController payrollController;
	@Autowired
    private UserAccountManager userManager;
	
	
	@BeforeAll
    public void setUp() {
		model = mock(Model.class);
		ra = mock(RedirectAttributes.class);
        user = userManager.findAll().iterator().next();
        product = new Product("Hut",Money.of(30.0, EURO));
        Order order = new Order(user, Cash.CASH);
        Cart cart = new Cart();
        cart.addOrUpdateItem(product, quantity);
        cart.addItemsTo(order);
        
	}
	
	
	@Test
	public void testGetAccountans() {
		
		AccountancyEntry aEntry = new AccountancyEntry(Money.of(30.0, EURO));		
		accountancy.add(aEntry); 
		Assertions.assertTrue(accountancyController.getAccountans(year).containsKey(pDate));
		
	}
	
	@Test
	@WithMockUser(username="boss",roles={"BOSS"})
	public void testRevenue() {
		AccountancyEntry aEntry = new AccountancyEntry(Money.of(30.0, EURO));
		Assertions.assertNotNull(accountancyController.showRevenue("2019", model), "should not be null");
		
	}
	
	@Test
	@WithMockUser(username="boss",roles={"BOSS"})
	public void testExpense() {
		payrollController.doPayroll(5000, "mia", 2019, 02, ra);
		Assertions.assertNotNull(accountancyController.showExpense(model, 2019), "should not be null");
	}
	
	
	
}
