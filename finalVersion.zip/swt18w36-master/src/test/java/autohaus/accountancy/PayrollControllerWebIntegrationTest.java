package autohaus.accountancy;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import autohaus.AbstractWebIntegrationTest;

public class PayrollControllerWebIntegrationTest extends AbstractWebIntegrationTest{

	@Test
    public void testPayroll() {
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get("/payroll").with(user("boss").roles("BOSS"))).andExpect(status().isOk())
                    .andExpect(view().name("payroll"));
        });
    }
	
	@Test
    public void testMyPayroll() {
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get("/mypayroll").with(user("mia").roles("EMPLOYEE"))).andExpect(status().isOk())
                    .andExpect(view().name("mypayroll"));
        });
    }
}
