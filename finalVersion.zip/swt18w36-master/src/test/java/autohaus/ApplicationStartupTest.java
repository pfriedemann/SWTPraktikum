package autohaus;

import org.junit.jupiter.api.Test;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;

class ApplicationStartupTest extends AbstractIntegrationTest {

    private AutohausStartupCommandLineRunner cmdRunner;
    @Autowired
    private UserAccountManager uam;

    @BeforeAll
    void setUp() {
        cmdRunner = new AutohausStartupCommandLineRunner(uam);
    }

    @Test
    void crosstestingMessage() {
        assertDoesNotThrow(() -> {
            cmdRunner.run();
        });
    }
}
