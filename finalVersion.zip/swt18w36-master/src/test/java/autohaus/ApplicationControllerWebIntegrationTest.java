package autohaus;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.springframework.boot.test.context.SpringBootTest;

@TestInstance(Lifecycle.PER_CLASS)
@SpringBootTest
public class ApplicationControllerWebIntegrationTest extends AbstractWebIntegrationTest {

    @Test
    void indexMvcIntegrationTest() throws Exception {
        mvc.perform(get("/")).andExpect(status().isOk());
    }
}
