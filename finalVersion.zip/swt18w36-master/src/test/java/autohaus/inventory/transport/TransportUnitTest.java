package autohaus.inventory.transport;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.salespointframework.catalog.Product;
import org.salespointframework.quantity.Quantity;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import autohaus.inventory.Location;
import autohaus.inventory.ResidentInventoryItem;

@TestInstance(Lifecycle.PER_CLASS)
public class TransportUnitTest {
    private Transport transport;
    private ResidentInventoryItem sourceItem;
    private ResidentInventoryItem targetItem;
    private LocalDateTime timeStart;
    private LocalDateTime timeEnd;
    private Location locationStart;
    private Location locationEnd;
    private Product product;
    private final Quantity quantity = Quantity.of(100);
    
    @BeforeAll
    void setUp(){
        sourceItem = mock(ResidentInventoryItem.class);
        targetItem = mock(ResidentInventoryItem.class);
        timeStart = LocalDateTime.parse("2018-12-24T10:12");
        timeEnd = LocalDateTime.parse("2018-12-25T10:12");
        locationStart = mock(Location.class);
        locationEnd = mock(Location.class);
        product = mock(Product.class);
        when(sourceItem.getLocation()).thenReturn(locationStart);
        when(sourceItem.hasSufficientQuantity(quantity)).thenReturn(true);
        when(sourceItem.getProduct()).thenReturn(product);
        when(targetItem.getProduct()).thenReturn(product);
        when(targetItem.getLocation()).thenReturn(locationEnd);
        
        
        transport = new Transport(timeStart,timeEnd,quantity,sourceItem,targetItem);
    }
    
    @Test
    void testTransportFields() {
        assertTrue(transport.getSource().equals(sourceItem));
        assertTrue(transport.getTarget().equals(targetItem));
        assertTrue(transport.getFrom().equals(locationStart));
        assertTrue(transport.getTo().equals(locationEnd));
        assertTrue(transport.getProduct().equals(product));
    }
}
