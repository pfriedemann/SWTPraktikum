package autohaus.inventory.transport;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.springframework.boot.test.context.SpringBootTest;

import autohaus.inventory.Location;

@TestInstance(Lifecycle.PER_CLASS)
@SpringBootTest
public class TransportFormUnitTest {

    private TransportForm form;
    
    @BeforeAll
    void setUp(){
        form = new TransportForm();
    }
    
    @Test
    void test(){
        form.setAmount(1);
        assertTrue(form.getAmount() == 1);
        form.setDateEnd("01-02-2010");
        assertTrue(form.getDateEnd().equals("01-02-2010"));
        final Location location = new Location("test Location");
        form.setLocation(location);
        assertTrue(form.getLocation().equals(location));
        form.setTimeEnd("11:22");
        assertTrue(form.getTimeEnd().equals("11:22"));
    }
}
