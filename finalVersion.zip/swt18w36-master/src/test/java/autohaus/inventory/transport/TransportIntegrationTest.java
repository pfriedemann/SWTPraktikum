package autohaus.inventory.transport;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.salespointframework.quantity.Quantity;
import org.salespointframework.time.BusinessTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import autohaus.AbstractIntegrationTest;
import autohaus.catalog.Auto;
import autohaus.catalog.AutoCatalog;
import autohaus.inventory.Location;
import autohaus.inventory.LocationRepository;
import autohaus.inventory.MultiLocationInventory;
import autohaus.inventory.OutOfStockException;
import autohaus.inventory.ResidentInventoryItem;
import autohaus.inventory.transport.Transport.TransportStatus;
import autohaus.inventory.transport.TransportService;

@TestInstance(Lifecycle.PER_CLASS)
@SpringBootTest
public class TransportIntegrationTest extends AbstractIntegrationTest {
    private TransportService transportService;
    private TransportRepository transportRepository;
    private MultiLocationInventory inventory;
    private LocationRepository locations;
    private AutoCatalog catalog;
    private BusinessTime time;
    private Location from;
    private Location to;
    private Auto product;

    @Autowired
    private void setTransportRepository(TransportRepository transportRepository) {
        this.transportRepository = transportRepository;
    }

    @Autowired
    private void setTransportManager(TransportService service) {
        this.transportService = service;
    }

    @Autowired
    private void setTransportManager(MultiLocationInventory inventory) {
        this.inventory = inventory;
    }

    @Autowired
    private void setTransportManager(LocationRepository locations) {
        this.locations = locations;
    }

    @Autowired
    private void setCatalog(AutoCatalog catalog) {
        this.catalog = catalog;
    }

    @Autowired
    private void setTime(BusinessTime time) {
        this.time = time;
    }

    @BeforeAll
    public void setUp() {
        Location sourceLocation = new Location("test");
        Location targetLocation = new Location("testTarget");
        locations.save(sourceLocation);
        locations.save(targetLocation);
        Iterator<Location> iteratorLocations = locations.findAll().iterator();
        from = iteratorLocations.next();
        to = iteratorLocations.next();
        assertTrue(catalog.count() > 0);
        Iterator<Auto> iteratorCatalog = catalog.findAll().iterator();
        product = iteratorCatalog.next();
    }

    @Test
    public void testTransport() {
        assertTrue(inventory.count() > 0);
        ResidentInventoryItem sourceItem = inventory.findByProductAndLocation(product, from).get();
        ResidentInventoryItem targetItem = inventory.findByProductAndLocation(product, to).get();
        Quantity sourceBefore = sourceItem.getQuantity();
        Quantity targetBefore = targetItem.getQuantity();
        final Quantity toMove = sourceBefore;
        assertDoesNotThrow(() -> {
            transportService.moveItemsImmediately(product, toMove, from, to);
        });
        assertTrue(targetItem.getQuantity().equals(targetBefore.add(toMove)));
        assertTrue(sourceItem.getQuantity().equals(sourceBefore.subtract(toMove)));
        assertThrows(OutOfStockException.class, () -> {
            transportService.moveItemsImmediately(product, sourceBefore, from, to);
        });
    }

    @Test
    public void testTransportRepository() {
        ResidentInventoryItem source = inventory.findByProductAndLocation(product, from).get();
        ResidentInventoryItem target = inventory.findByProductAndLocation(product, to).get();
        final Quantity toMove = Quantity.of(5);
        Transport transport = new Transport(time.getTime(), time.getTime().plus(Duration.ofSeconds(2)), toMove, source,
                target);
        transportRepository.save(transport);
        assertTrue(transportRepository.count() == 1);
        assertTrue(!transportRepository.findOpen().isEmpty());
        Transport openTransport = transportRepository.findOpen().iterator().next();
        assertTrue(openTransport.getStatus().equals(TransportStatus.OPEN));
    }

    @Test
    public void testDelayedTransport() {
        final Duration duration = Duration.ofSeconds(1);
        final Duration forward = Duration.ofSeconds(5);
        final Quantity toMove = Quantity.of(5);
        ResidentInventoryItem target = inventory.findByProductAndLocation(product, to).get();
        Quantity preExecutionQuantity = target.getQuantity();
        long countPre = transportRepository.count();
        transportService.initiateTransport(from, to, product, toMove, time.getTime().plus(duration));
        assertTrue(transportRepository.count() == countPre+1);
        time.forward(forward);
        transportService.taskCheckRepository();
        ResidentInventoryItem target2 = inventory.findByProductAndLocation(product, to).get();
        Quantity postExecutionQuantity = target2.getQuantity();
        assertTrue(postExecutionQuantity.equals(preExecutionQuantity.add(toMove)),
                String.format("quantity changed from %s to %s, expected %s", preExecutionQuantity.toString(),
                        postExecutionQuantity.toString(), preExecutionQuantity.add(toMove)));
    }
    
    @Test
    public void testFindAll() {
        //fill some data in and check the count of returned elements by transportService
        ResidentInventoryItem source = inventory.findByProductAndLocation(product, from).get();
        ResidentInventoryItem target = inventory.findByProductAndLocation(product, to).get();
        final Quantity toMove = Quantity.of(5);
        LocalDateTime start = time.getTime();
        transportRepository.save(new Transport(start,start.plus(Duration.ofDays(1)), toMove, source, target));
        transportRepository.save(new Transport(start,start.plus(Duration.ofDays(1)), toMove.add(Quantity.of(1)), target,source));
        Iterable<Transport> transports = transportService.findAll();

        long elements = 0;
        for (Transport transport : transports) {
            ++elements;
        }
        assertTrue(elements == transportRepository.count());
    }
}
