package autohaus.inventory.transport;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.salespointframework.time.BusinessTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import autohaus.AbstractWebIntegrationTest;
import autohaus.inventory.Location;
import autohaus.inventory.LocationRepository;
import autohaus.inventory.MultiLocationInventory;
import autohaus.inventory.ResidentInventoryItem;

@TestInstance(Lifecycle.PER_CLASS)
@SpringBootTest
public class TransportControllerWebIntegrationTest extends AbstractWebIntegrationTest {

    ResidentInventoryItem item;
    Location location;
    MultiLocationInventory inventory;
    LocationRepository locations;
    BusinessTime time;

    @Autowired
    void setInventory(MultiLocationInventory inventory) {
        this.inventory = inventory;
    }

    @Autowired
    void setTime(BusinessTime time) {
        this.time = time;
    }

    @Autowired
    void setLocations(LocationRepository locations) {
        this.locations = locations;
    }

    @BeforeAll
    public void setUp2() {
        item = inventory.findAll().iterator().next();
        location = locations.findAll().iterator().next();
    }

    @Test
    void testInterface() {
        String url = "/transport/" + item.getId().toString();
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get(url).with(user("boss").roles("BOSS"))).andExpect(status().isOk())
                    .andExpect(view().name("transport"));
        });
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get(url)).andExpect(status().is3xxRedirection());
        });
    }
}
