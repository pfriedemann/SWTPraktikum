package autohaus.inventory.transport;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.salespointframework.time.BusinessTime;
import org.springframework.ui.Model;

import autohaus.inventory.LocationRepository;
import autohaus.inventory.ResidentInventoryItem;

import static org.mockito.Mockito.*;

import java.time.Duration;
import java.util.LinkedList;

@TestInstance(Lifecycle.PER_CLASS)
public class TransportControllerUnitTest {

    private TransportController controller;
    private LocationRepository locationRepository;
    private TransportService transportService;
    private BusinessTime time;
    private Model model;
    private ResidentInventoryItem item;
    
    private LinkedList<Transport> transports;
    
    @BeforeAll
    public void setUp() {
        model = mock(Model.class);
        locationRepository = mock(LocationRepository.class);
        time = mock(BusinessTime.class);
        
        Transport transportA = mock(Transport.class);
        Transport transportB = mock(Transport.class);
        
        //Transport Service
        transportService = mock(TransportService.class);
        transports = new LinkedList<>();
        transports.add(transportA);
        transports.add(transportB);
        when(transportService.findAll()).thenReturn(transports);
        //Test Subject
        controller = new TransportController(locationRepository, transportService,time);
    }
    
    @Test
    public void testTimeTravel() {
        String result = controller.forwardTime();
        assertDoesNotThrow(() -> {
            verify(time,times(1)).forward(any(Duration.class));
        });
    }
    
    @Test
    public void testShowTransports() {
        String result = controller.showTransports(model);
        assertDoesNotThrow( () -> {
           verify(model,times(1)).addAttribute("transports", transports); 
        });
        assertTrue(result.equals("transport_history"));
    }
}
