package autohaus.inventory;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.salespointframework.quantity.Quantity;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@TestInstance(Lifecycle.PER_CLASS)
public class InventoryControllerUnitTest {

    private InventoryController controller;
    private MultiLocationInventory inventory;
    private LocationRepository locations;
    private Location location;
    private LocationIdentifier locationId;
    private ResidentInventoryItem item;
    private final Quantity quantity = Quantity.of(100);
    private RedirectAttributes ra;
    
    @BeforeAll
    public void setUp() {
        inventory = mock(MultiLocationInventory.class);
        locations = mock(LocationRepository.class);
        location = mock(Location.class);
        //can't mock final class
        locationId = new LocationIdentifier("0xDEADBEEF");
        item = mock(ResidentInventoryItem.class);
        ra = mock(RedirectAttributes.class);
        controller = new InventoryController(inventory, locations);
        
        when(inventory.save(item)).thenReturn(item);
        when(item.hasSufficientQuantity(quantity)).thenReturn(true);
        when(location.getId()).thenReturn(locationId);
    }
    
    @Test
    public void testChangeQuantity() {
        String awnser1 = controller.changeQuantity(item, quantity, location, "increase", ra);
        assertDoesNotThrow(() -> {
            verify(item,times(1)).increaseQuantity(quantity);
        });
        assertTrue(awnser1.length() > 0);
        String awnser2 = controller.changeQuantity(item, quantity, location, "decrease", ra);
        assertDoesNotThrow(() -> {
            verify(item,times(1)).decreaseQuantity(quantity);
        });
        assertTrue(awnser2.length() > 0);
        
    }
}
