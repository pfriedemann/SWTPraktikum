package autohaus.inventory;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.springframework.boot.test.context.SpringBootTest;

import autohaus.AbstractWebIntegrationTest;

@TestInstance(Lifecycle.PER_CLASS)
@SpringBootTest
public class InventoryControllerWebIntegrationTest extends AbstractWebIntegrationTest {

    @Test
    public void testStock() {
        Assertions.assertDoesNotThrow(() -> {
            mvc.perform(get("/inventory").with(user("boss").roles("BOSS"))).andExpect(status().isOk())
                    .andExpect(view().name("locations"));// .//
            // andExpect(model().attributeExists("ordersCompleted"));*/
        });
    }
}
