package autohaus.inventory;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.salespointframework.core.Currencies.*;

import org.javamoney.moneta.Money;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.salespointframework.catalog.Catalog;
import org.salespointframework.catalog.Product;
import org.salespointframework.order.Cart;
import org.salespointframework.order.Order;
import org.salespointframework.order.Order.OrderCompleted;
import org.salespointframework.quantity.Quantity;
import org.salespointframework.order.OrderManager;
import org.salespointframework.payment.Cash;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.beans.factory.annotation.Autowired;

import autohaus.AbstractIntegrationTest;

@TestInstance(Lifecycle.PER_CLASS)
public class AutohausInventoryOrderEventListenerIntegrationTest extends AbstractIntegrationTest {
    
    private Order order;
    private Order oversizedOrder;
    private UserAccount user;
    private Product product;
    private Location location;
    private final Quantity quantity = Quantity.of(100);

    @Autowired
    private UserAccountManager userManager;
    @Autowired
    private MultiLocationInventory inventory;
    @Autowired
    private LocationRepository locations;
    @Autowired
    private AutohausInventoryOrderEventListener eventListener; // Test Subject
    @Autowired
    private Catalog<Product> catalog;
    @Autowired
    private OrderManager<Order> orderManager;

    @BeforeAll
    public void setUp() {
        user = userManager.findAll().iterator().next();
        //product = catalog.findAll().iterator().next();
        product = new Product("ridiculous sunglasses",Money.of(50.0, EURO));
        location = new Location("testSite");
        product = catalog.save(product);
        location = locations.save(location);
        
    }

    @BeforeEach
    public void setUpTest() {
        // fill inventory
        ResidentInventoryItem item = new ResidentInventoryItem(product,quantity,location);
        //replace item
        inventory.save(item);
        // prepare Order
        order = new Order(user, Cash.CASH);
        Cart cart = new Cart();
        cart.addOrUpdateItem(product, quantity);
        cart.addItemsTo(order);
        // prepare exception causing Order
        oversizedOrder = new Order(user, Cash.CASH);
        Cart oversizedCart = new Cart();
        oversizedCart.addOrUpdateItem(product, item.getQuantity().add(quantity));
        oversizedCart.addItemsTo(oversizedOrder);
        order = orderManager.save(order);
        oversizedOrder = orderManager.save(oversizedOrder);
    }
    
    @Test
    public void testOrderEventListener() {
        Quantity preExecution = Quantity.of(0);
        for (ResidentInventoryItem item : inventory.findByProduct(product)) {
            preExecution = preExecution.add(item.getQuantity());
        }
        assertDoesNotThrow(() -> {
            eventListener.handleEvent(OrderCompleted.of(order));
        });
        //try the over sized
        assertThrows(OutOfStockException.class,() -> {
            eventListener.handleEvent(OrderCompleted.of(oversizedOrder));
        });
        Quantity postExecution = Quantity.of(0);
        for (ResidentInventoryItem item : inventory.findByProduct(product)) {
            postExecution = postExecution.add(item.getQuantity());
        }
        assertTrue(postExecution.equals(preExecution.subtract(quantity)),
                String.format("expected %s got %s", preExecution.subtract(quantity), postExecution));
    }
    
    @Test
    public void testOrderEvent() {
        Quantity preExecution = inventory.totalStockOf(product);
        //test normal Order
        
        assertDoesNotThrow(() -> {
            orderManager.payOrder(order);
            orderManager.completeOrder(order);
        });
        Quantity postExecution = inventory.totalStockOf(product);
        assertTrue(postExecution.equals(preExecution.subtract(quantity)),
                String.format("expected %s got %s", preExecution.subtract(quantity), postExecution));
        assertTrue(order.isCompleted(),String.format("order is %s", order.getOrderStatus()));
        
        assertThrows(OutOfStockException.class,() -> {
            orderManager.payOrder(oversizedOrder);
            orderManager.completeOrder(oversizedOrder);
        });
        assertTrue(postExecution.equals(preExecution.subtract(quantity)),
                String.format("expected %s got %s", preExecution.subtract(quantity), postExecution));
        //cancel OrderCompletion is impossible
        //assertTrue(oversizedOrder.isPaid(),String.format("oversizedOrder is %s", oversizedOrder.getOrderStatus().toString()));
    }
}
