package autohaus.inventory;

import java.util.Iterator;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import autohaus.AbstractIntegrationTest;
import autohaus.catalog.Auto;
import autohaus.catalog.AutoCatalog;

public class InventoryIntegrationTest extends AbstractIntegrationTest {
    private MultiLocationInventory inventory;
    private LocationRepository locations;
    private AutoCatalog catalog;

    @Autowired
    private void setInventory(MultiLocationInventory inventory) {
        this.inventory = inventory;
    }

    @Autowired
    private void setLocationRepository(LocationRepository locations) {
        this.locations = locations;
    }

    @Autowired
    private void setLocationRepository(AutoCatalog catalog) {
        this.catalog = catalog;
    }


    @Test
    public void listInventory() {
        Optional<Location> location = locations.findByName("Dresden");
        // inventory is initialized
        Assertions.assertTrue(inventory.count() > 0);
        Assertions.assertTrue(location.isPresent(), "Location \"Dresden\" not found");
        // location has items
        Assertions.assertTrue(inventory.findByLocation(location.get()).iterator().hasNext(),
                "Location \"Dresden\" has no items");
    }

    /**
     * first checks for the first product from the catalog then runs a query for
     * that product on the inventory
     */
    @Test
    public void findProduct() {
        Iterator<Auto> products = catalog.findAll().iterator();
        Assertions.assertTrue(products.hasNext());
        Auto product = products.next();
        Streamable<ResidentInventoryItem> result = inventory.findByProduct(product);
        Assertions.assertTrue(!result.isEmpty());
        result.forEach(item -> {
            Assertions.assertTrue(item.getProduct().equals(product));
        });
        Optional<Location> location = locations.findByName("Dresden");
        Assertions.assertTrue(location.isPresent());
        Optional<ResidentInventoryItem> item = inventory.findByProductAndLocation(product, location.get());
        Assertions.assertTrue(item.isPresent());
        Assertions.assertTrue(item.get().getProduct().equals(product));
        Assertions.assertTrue(item.get().getLocation().equals(location.get()));
        Assertions.assertDoesNotThrow(() -> {
            inventory.totalStockOf(product);
        });
    }
}
