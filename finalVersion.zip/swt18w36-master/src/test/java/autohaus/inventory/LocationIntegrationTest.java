package autohaus.inventory;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import autohaus.AbstractIntegrationTest;

public class LocationIntegrationTest extends AbstractIntegrationTest {

    private LocationRepository locations;
    private final String testLocationName = "Mushroom Kingdom";
    
    @Autowired
    private void setLocations(LocationRepository locations) {
        this.locations = locations;
    }

    
    @BeforeAll
    public void setUp() {
        locations.save(new Location(testLocationName,"Toads House"));
    }
    
    @Test
    public void listLocations() {
        Assertions.assertTrue(locations.findByName(testLocationName).isPresent());
        Assertions.assertTrue(locations.findByName(testLocationName).get().getName().equals(testLocationName));
    }
}
