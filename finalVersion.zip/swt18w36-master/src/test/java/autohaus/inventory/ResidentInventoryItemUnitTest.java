package autohaus.inventory;

import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.salespointframework.quantity.Quantity;

import autohaus.catalog.Auto;

@TestInstance(Lifecycle.PER_CLASS)
public class ResidentInventoryItemUnitTest {
    private ResidentInventoryItem item;
    private Auto product;
    private Location location;
    private final Quantity quantity = Quantity.of(20);

    @BeforeAll
    void setUp() {
        product = mock(Auto.class);
        location = mock(Location.class);
        item = new ResidentInventoryItem(product, quantity, location);
    }

    @Test
    void run() {
        Assertions.assertTrue(item.getLocation().equals(location));
        Assertions.assertTrue(item.getQuantity().equals(quantity));
        item.increaseQuantity(quantity);
        Assertions.assertTrue(item.hasSufficientQuantity(quantity.add(quantity)));
        item.decreaseQuantity(quantity);
        Assertions.assertTrue(item.getQuantity().equals(quantity));
    }

}
